
import express from "express";
import Stripe from "stripe";
import { db } from "./db";
import { users } from "../shared/schema";
import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, {
  apiVersion: "2023-10-16",
});

const router = express.Router();

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  stripeSessionId: text("stripe_session_id").notNull().unique(),
  amount: integer("amount").notNull(),
  type: text("type").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

router.post("/create-checkout-session", async (req, res) => {
  try {
    const { userId, amount } = req.body;

    if (!userId || !amount || amount <= 0) {
      return res.status(400).json({ error: "Invalid request" });
    }

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      mode: "payment",
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: { name: "DAH Coins Purchase" },
            unit_amount: amount * 100,
          },
          quantity: 1,
        },
      ],
      metadata: {
        userId: String(userId),
        amount: String(amount),
      },
      success_url: `${process.env.CLIENT_URL}/wallet?success=true`,
      cancel_url: `${process.env.CLIENT_URL}/wallet?canceled=true`,
    });

    res.json({ url: session.url });
  } catch (error) {
    console.error("Stripe Session Error:", error);
    res.status(500).json({ error: "Failed to create session" });
  }
});

router.post(
  "/webhook",
  express.raw({ type: "application/json" }),
  async (req, res) => {
    const signature = req.headers["stripe-signature"] as string;

    let event;

    try {
      event = stripe.webhooks.constructEvent(
        req.body,
        signature,
        process.env.STRIPE_WEBHOOK_SECRET as string
      );
    } catch (err) {
      console.error("Webhook signature failed.");
      return res.status(400).send("Invalid signature");
    }

    if (event.type === "checkout.session.completed") {
      const session = event.data.object as Stripe.Checkout.Session;

      const userId = Number(session.metadata?.userId);
      const amount = Number(session.metadata?.amount);

      if (!userId || !amount) {
        return res.status(400).send("Missing metadata");
      }

      try {
        const existing = await db.query.transactions.findFirst({
          where: (t, { eq }) => eq(t.stripeSessionId, session.id),
        });

        if (existing) {
          return res.json({ received: true });
        }

        await db.transaction(async (trx) => {
          const currentUser = await trx.query.users.findFirst({
            where: (u, { eq }) => eq(u.id, userId),
          });

          if (!currentUser) throw new Error("User not found");

          await trx.update(users)
            .set({ dahCoins: currentUser.dahCoins + amount })
            .where((u, { eq }) => eq(u.id, userId));

          await trx.insert(transactions).values({
            userId,
            stripeSessionId: session.id,
            amount,
            type: "purchase",
          });
        });

      } catch (err) {
        console.error("Database transaction failed:", err);
        return res.status(500).send("Database error");
      }
    }

    res.json({ received: true });
  }
);

export default router;
