

ADD THIS FILE TO YOUR PROJECT:

1. Place stripePayments.ts inside /server

2. Install dependencies:
   npm install stripe express-rate-limit

3. In server/index.ts add:

   import stripePayments from "./stripePayments";
   app.use("/api/payments", stripePayments);

4. Add environment variables:

   STRIPE_SECRET_KEY=sk_live_xxxxx
   STRIPE_WEBHOOK_SECRET=whsec_xxxxx
   CLIENT_URL=http://localhost:5173

5. Run drizzle migration if transactions table does not exist.

