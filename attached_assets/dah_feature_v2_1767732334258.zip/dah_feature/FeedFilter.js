import React, { useState } from 'react';
import './FeedFilter.css';

export default function FeedFilter({ posts }) {
  const [filter, setFilter] = useState('all');

  const filteredPosts = posts.filter(post => {
    if (filter === 'all') return true;
    return post.type === filter;
  });

  return (
    <div className="feed-filter">
      <div className="feed-filter-controls">
        <button onClick={() => setFilter('all')}>All</button>
        <button onClick={() => setFilter('social')}>Social</button>
        <button onClick={() => setFilter('market')}>Marketplace</button>
      </div>

      <div className="feed-filter-posts">
        {filteredPosts.map(post => (
          <div key={post.id} className="feed-post">
            {post.content}
          </div>
        ))}
      </div>
    </div>
  );
}
