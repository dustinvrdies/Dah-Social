# Feed Filter Component for DAH Social

Adds a simple feed filter so users can toggle between:
- All posts
- Social posts
- Marketplace posts

This improves UX by reducing feed clutter and giving users control.
