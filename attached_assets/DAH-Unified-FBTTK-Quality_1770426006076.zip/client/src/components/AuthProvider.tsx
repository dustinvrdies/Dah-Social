import { createContext, useContext, useCallback, useEffect, useMemo, useState, ReactNode } from "react";
import { apiRequest } from "@/lib/queryClient";

export type SessionUser = { id: string; username: string; age?: number };

type AuthCtx = {
  session: SessionUser | null;
  isLoading: boolean;
  refreshSession: () => Promise<void>;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthCtx>({
  session: null,
  isLoading: true,
  refreshSession: async () => {},
  login: async () => {},
  logout: async () => {},
});

export const useAuth = () => useContext(AuthContext);

async function fetchMe(): Promise<SessionUser | null> {
  const res = await fetch("/api/auth/me", { credentials: "include" });
  if (!res.ok) return null;
  const data = await res.json();
  return data?.user ?? null;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<SessionUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const refreshSession = useCallback(async () => {
    setIsLoading(true);
    try {
      const me = await fetchMe();
      setSession(me);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    void refreshSession();
  }, [refreshSession]);

  const login = useCallback(
    async (username: string, password: string) => {
      await apiRequest("POST", "/api/auth/login", { username, password });
      await refreshSession();
    },
    [refreshSession],
  );

  const logout = useCallback(async () => {
    await apiRequest("POST", "/api/auth/logout");
    await refreshSession();
  }, [refreshSession]);

  const value = useMemo(() => ({ session, isLoading, refreshSession, login, logout }), [session, isLoading, refreshSession, login, logout]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
