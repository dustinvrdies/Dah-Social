import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

type CreditedDetail = {
  amountCents: number;
  currency?: string;
  reason?: string;
};

function fmtMoney(cents: number, currency = "USD") {
  const dollars = (cents / 100).toFixed(2);
  return currency === "USD" ? `$${dollars}` : `${dollars} ${currency}`;
}

export function EarningsEventListener() {
  const { toast } = useToast();
  const qc = useQueryClient();

  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent<CreditedDetail>).detail;
      if (!detail || !Number.isFinite(detail.amountCents)) return;

      toast({
        title: "Earnings credited",
        description: `You earned ${fmtMoney(detail.amountCents, detail.currency ?? "USD")} for qualified ad engagement.`,
      });

      // Refresh earnings UI
      qc.invalidateQueries({ queryKey: ["/api/earnings/balance"] });
      qc.invalidateQueries({ queryKey: ["/api/earnings/ledger"] });
    };

    window.addEventListener("dah:earning_credited", handler as any);
    return () => window.removeEventListener("dah:earning_credited", handler as any);
  }, [toast, qc]);

  return null;
}
