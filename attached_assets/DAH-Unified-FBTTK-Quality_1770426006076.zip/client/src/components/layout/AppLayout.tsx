import { Link, useLocation } from "wouter";
import { Home, ShoppingBag, Wallet, User, Bell, Search, Menu, LogOut } from "lucide-react";
import { currentUser } from "@/lib/mockData";
import { cn } from "@/lib/utils";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import generatedLogo from "@assets/generated_images/dah_social_logo_neon_cyberpunk.png";

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [coins, setCoins] = useState(currentUser.coins);

  // Simulate passive coin earning
  useEffect(() => {
    const interval = setInterval(() => {
      setCoins(prev => prev + 1);
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  const navItems = [
    { icon: Home, label: "Feed", href: "/" },
    { icon: ShoppingBag, label: "DAH Mall", href: "/mall" },
    { icon: Wallet, label: "Wallet", href: "/wallet" },
    { icon: User, label: "Profile", href: "/profile" },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground flex font-sans selection:bg-primary selection:text-primary-foreground">
      {/* Sidebar - Desktop */}
      <aside className="hidden md:flex flex-col w-64 fixed inset-y-0 left-0 border-r border-sidebar-border bg-sidebar/80 backdrop-blur-xl z-50">
        <div className="p-6 flex items-center gap-3">
          <img src={generatedLogo} alt="DAH Logo" className="w-10 h-10 rounded-lg shadow-[0_0_15px_rgba(0,243,255,0.3)]" />
          <span className="font-display text-2xl font-bold tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
            DAH
          </span>
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-4">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;
            return (
              <Link key={item.href} href={item.href}>
                <a className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 group",
                  isActive 
                    ? "bg-primary/10 text-primary shadow-[0_0_20px_rgba(0,243,255,0.15)] border border-primary/20" 
                    : "text-muted-foreground hover:bg-white/5 hover:text-white"
                )}>
                  <Icon className={cn("w-5 h-5", isActive && "drop-shadow-[0_0_5px_rgba(0,243,255,0.5)]")} />
                  <span className={cn("font-medium", isActive && "font-bold")}>{item.label}</span>
                </a>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-sidebar-border">
          <div className="p-4 rounded-xl bg-gradient-to-br from-card to-card/50 border border-white/5">
            <div className="flex items-center gap-3 mb-3">
              <Avatar className="w-10 h-10 border border-white/10">
                <AvatarImage src={currentUser.avatar} />
                <AvatarFallback>K</AvatarFallback>
              </Avatar>
              <div className="flex-1 overflow-hidden">
                <p className="font-bold truncate text-sm">{currentUser.name}</p>
                <p className="text-xs text-muted-foreground truncate">{currentUser.handle}</p>
              </div>
            </div>
            <div className="flex items-center justify-between text-xs font-ui">
              <span className="text-muted-foreground">REPUTATION</span>
              <span className="text-primary font-bold">{currentUser.stats.reputation}%</span>
            </div>
            <div className="w-full h-1 bg-white/10 rounded-full mt-1 overflow-hidden">
              <div 
                className="h-full bg-primary shadow-[0_0_10px_var(--primary)]" 
                style={{ width: `${currentUser.stats.reputation}%` }}
              />
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Wrapper */}
      <main className="flex-1 md:ml-64 flex flex-col min-h-screen">
        {/* Top Header */}
        <header className="sticky top-0 z-40 w-full h-16 border-b border-white/5 bg-background/80 backdrop-blur-md px-4 flex items-center justify-between">
          <div className="md:hidden flex items-center gap-2">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="bg-sidebar border-r border-white/10">
                 {/* Mobile Nav Content */}
                 <div className="flex flex-col h-full mt-8">
                    {navItems.map((item) => (
                      <Link key={item.href} href={item.href}>
                         <a className={cn(
                          "flex items-center gap-4 px-4 py-4 text-lg font-medium border-b border-white/5",
                          location === item.href ? "text-primary" : "text-muted-foreground"
                         )}>
                            <item.icon className="w-6 h-6" />
                            {item.label}
                         </a>
                      </Link>
                    ))}
                 </div>
              </SheetContent>
            </Sheet>
            <span className="font-display text-xl font-bold text-primary">DAH</span>
          </div>

          <div className="hidden md:flex flex-1 max-w-md mx-4 relative group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
            <input 
              type="text" 
              placeholder="Search users, posts, items..." 
              className="w-full bg-white/5 border border-white/10 rounded-full py-2 pl-10 pr-4 text-sm focus:outline-none focus:border-primary/50 focus:bg-white/10 transition-all"
            />
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-secondary/10 border border-secondary/20 rounded-full">
              <div className="w-2 h-2 rounded-full bg-secondary animate-pulse" />
              <span className="font-ui font-bold text-secondary">{coins.toLocaleString()} DAH</span>
            </div>

            <Button variant="ghost" size="icon" className="relative hover:bg-white/5">
              <Bell className="w-5 h-5" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-destructive rounded-full border-2 border-background" />
            </Button>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 p-4 md:p-8 max-w-7xl mx-auto w-full animate-in fade-in duration-500">
          {children}
        </div>
      </main>
    </div>
  );
}
