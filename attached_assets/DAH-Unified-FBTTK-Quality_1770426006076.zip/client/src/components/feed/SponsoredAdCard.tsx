import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Info, ExternalLink } from "lucide-react";
import { useEffect, useRef } from "react";

export type FeedAd = {
  id: string;
  format: string;
  advertiser: string;
  advertiserHandle: string;
  advertiserVerified: boolean;
  headline: string;
  caption: string;
  media: string | null;
  mediaAlt: string | null;
  videoSrc: string | null;
  carouselImages: string | null;
  cta: string;
  ctaUrl: string;
};

export function SponsoredAdCard(props: {
  ad: FeedAd;
  onImpression: (adId: string) => void;
  onClick: (adId: string) => void;
  onQualifiedView: (adId: string, durationMs: number) => void;
}) {
  const { ad, onImpression, onClick, onQualifiedView } = props;
  const startRef = useRef<number>(Date.now());
  const impressedRef = useRef(false);

  useEffect(() => {
    if (!impressedRef.current) {
      impressedRef.current = true;
      onImpression(ad.id);
    }
  }, [ad.id, onImpression]);

  const elapsedMs = () => Math.max(0, Date.now() - startRef.current);

  return (
    <Card className="overflow-hidden border-dashed">
      <CardHeader className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span className="font-medium">Sponsored</span>
              <span>•</span>
              <span className="truncate">@{ad.advertiserHandle}</span>
              {ad.advertiserVerified ? <Badge variant="secondary">Verified</Badge> : null}
            </div>
            <div className="mt-1 truncate font-semibold">{ad.headline}</div>
            <div className="text-xs text-muted-foreground">{ad.advertiser}</div>
          </div>

          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Info className="h-4 w-4" />
            <span>Proven engagement only</span>
          </div>
        </div>
      </CardHeader>

      <CardContent className="px-4 pb-4 pt-0">
        <div className="whitespace-pre-wrap leading-relaxed text-sm text-foreground/90">{ad.caption}</div>

        {ad.videoSrc ? (
          <div className="mt-3 overflow-hidden rounded-xl border bg-muted">
            <video className="h-auto w-full" src={ad.videoSrc} controls playsInline preload="metadata" />
          </div>
        ) : ad.media ? (
          <div className="mt-3 overflow-hidden rounded-xl border bg-muted">
            <img src={ad.media} alt={ad.mediaAlt || "Sponsored media"} className="h-auto w-full object-cover" loading="lazy" />
          </div>
        ) : null}
      </CardContent>

      <CardFooter className="flex items-center justify-between gap-2 border-t p-2">
        <Button
          className="gap-2"
          onClick={() => {
            const ms = elapsedMs();
            onQualifiedView(ad.id, ms);
            onClick(ad.id);
            window.open(ad.ctaUrl, "_blank", "noopener,noreferrer");
          }}
        >
          {ad.cta}
          <ExternalLink className="h-4 w-4" />
        </Button>

        <Button variant="ghost" onClick={() => onQualifiedView(ad.id, elapsedMs())}>
          Mark viewed
        </Button>
      </CardFooter>
    </Card>
  );
}
