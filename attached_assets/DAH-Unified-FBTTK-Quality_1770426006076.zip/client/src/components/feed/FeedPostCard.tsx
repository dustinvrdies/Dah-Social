import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, Share2, Bookmark, MoreHorizontal } from "lucide-react";
import { cn } from "@/lib/utils";
import { useMemo } from "react";

export type FeedMedia = { url: string; type: "image" | "video" };
export type FeedPost = {
  id: string;
  userId: string;
  content: string;
  createdAt: string;
  username: string;
  profile: { displayName?: string | null; avatarUrl?: string | null } | null;
  likeCount: number;
  commentCount: number;
  media?: FeedMedia[];
  viewer?: { liked: boolean; bookmarked?: boolean } | null;
};

export function FeedPostCard(props: {
  post: FeedPost;
  onLike: (postId: string, liked: boolean) => void;
  onOpenComments?: (postId: string) => void;
  onShare?: (postId: string) => void;
}) {
  const { post, onLike, onOpenComments, onShare } = props;

  const displayName = post.profile?.displayName || post.username;
  const avatar = post.profile?.avatarUrl || undefined;

  const primaryMedia = useMemo(() => {
    const m = post.media?.[0];
    return m ? m : null;
  }, [post.media]);

  const timeLabel = useMemo(() => {
    const d = new Date(post.createdAt);
    const delta = Date.now() - d.getTime();
    const minutes = Math.floor(delta / 60_000);
    if (minutes < 1) return "just now";
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h`;
    const days = Math.floor(hours / 24);
    return `${days}d`;
  }, [post.createdAt]);

  return (
    <Card className="overflow-hidden">
      <CardHeader className="flex flex-row items-center gap-3 p-4">
        <Avatar className="h-10 w-10">
          <AvatarImage src={avatar} alt={displayName} />
          <AvatarFallback>{displayName.slice(0, 2).toUpperCase()}</AvatarFallback>
        </Avatar>

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <div className="truncate font-semibold">{displayName}</div>
            <div className="text-xs text-muted-foreground">@{post.username}</div>
            <div className="text-xs text-muted-foreground">•</div>
            <div className="text-xs text-muted-foreground">{timeLabel}</div>
          </div>
        </div>

        <Button variant="ghost" size="icon" aria-label="More">
          <MoreHorizontal className="h-4 w-4" />
        </Button>
      </CardHeader>

      <CardContent className="px-4 pb-4 pt-0">
        <div className="whitespace-pre-wrap break-words leading-relaxed">{post.content}</div>

        {primaryMedia ? (
          <div className="mt-3 overflow-hidden rounded-xl border bg-muted">
            {primaryMedia.type === "video" ? (
              <video
                className="h-auto w-full"
                src={primaryMedia.url}
                controls
                playsInline
                preload="metadata"
              />
            ) : (
              <img className="h-auto w-full object-cover" src={primaryMedia.url} alt="Post media" loading="lazy" />
            )}
          </div>
        ) : null}
      </CardContent>

      <CardFooter className="flex items-center justify-between gap-2 border-t p-2">
        <Button
          variant="ghost"
          className={cn("gap-2", post.viewer?.liked ? "text-red-500" : "")}
          onClick={() => onLike(post.id, !!post.viewer?.liked)}
          aria-label={post.viewer?.liked ? "Unlike" : "Like"}
        >
          <Heart className="h-4 w-4" />
          <span className="text-sm">{post.likeCount}</span>
        </Button>

        <Button variant="ghost" className="gap-2" onClick={() => onOpenComments?.(post.id)} aria-label="Comments">
          <MessageCircle className="h-4 w-4" />
          <span className="text-sm">{post.commentCount}</span>
        </Button>

        <Button variant="ghost" className="gap-2" onClick={() => onShare?.(post.id)} aria-label="Share">
          <Share2 className="h-4 w-4" />
          <span className="text-sm">Share</span>
        </Button>

        <Button variant="ghost" size="icon" aria-label="Bookmark">
          <Bookmark className="h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  );
}
