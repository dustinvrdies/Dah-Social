import { currentUser, users } from "@/lib/mockData";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Music, Video, Star, Edit, Share2, ShieldCheck, MapPin, Link as LinkIcon } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

export default function Profile() {
  const [theme, setTheme] = useState("neon-cyan");
  
  const themes = [
    { id: "neon-cyan", name: "Cyber Cyan", primary: "180 100% 50%", secondary: "270 100% 60%" },
    { id: "hot-pink", name: "Hot Pink", primary: "330 100% 50%", secondary: "200 100% 50%" },
    { id: "matrix-green", name: "Matrix", primary: "120 100% 50%", secondary: "0 0% 100%" },
  ];

  const toggleTheme = () => {
    const currentIndex = themes.findIndex(t => t.id === theme);
    const nextTheme = themes[(currentIndex + 1) % themes.length];
    setTheme(nextTheme.id);
  };

  const activeTheme = themes.find(t => t.id === theme)!;

  return (
    <div 
      className="min-h-screen pb-20 transition-colors duration-500"
      style={{
        // @ts-ignore
        "--primary": activeTheme.primary,
        "--secondary": activeTheme.secondary,
      }}
    >
      {/* Banner */}
      <div className="relative h-64 md:h-80 w-full overflow-hidden rounded-b-3xl border-b border-primary/30 group">
        <img 
          src={currentUser.cover} 
          alt="Cover" 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
        
        <div className="absolute top-4 right-4 flex gap-2">
           <Button 
            variant="secondary" 
            size="sm" 
            onClick={toggleTheme}
            className="backdrop-blur-md bg-black/50 border border-white/10 hover:bg-black/70"
          >
             <Edit className="w-4 h-4 mr-2" />
             Theme: {activeTheme.name}
           </Button>
           <Button variant="secondary" size="sm" className="backdrop-blur-md bg-black/50 border border-white/10 hover:bg-black/70">
             <Share2 className="w-4 h-4" />
           </Button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 -mt-24 relative z-10">
        <div className="flex flex-col md:flex-row gap-6 items-end md:items-start">
          {/* Avatar */}
          <div className="relative">
            <div className="w-40 h-40 rounded-full p-1 bg-gradient-to-tr from-primary to-secondary shadow-[0_0_30px_rgba(0,243,255,0.3)]">
              <Avatar className="w-full h-full border-4 border-background">
                <AvatarImage src={currentUser.avatar} className="object-cover" />
                <AvatarFallback>ME</AvatarFallback>
              </Avatar>
            </div>
            {currentUser.isTeen && (
              <Badge className="absolute bottom-2 right-2 bg-secondary text-white border-2 border-background px-3 py-1">
                TEEN
              </Badge>
            )}
          </div>

          {/* Info */}
          <div className="flex-1 pt-4 md:pt-24 space-y-2">
             <div className="flex items-center gap-3">
               <h1 className="text-4xl font-display font-bold text-white neon-text-cyan">{currentUser.name}</h1>
               <Badge variant="outline" className="border-primary/50 text-primary gap-1">
                 <ShieldCheck className="w-3 h-3" />
                 Verified
               </Badge>
             </div>
             <p className="text-muted-foreground font-ui text-lg">{currentUser.handle}</p>
             
             <div className="flex items-center gap-6 text-sm text-muted-foreground pt-2">
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4 text-primary" />
                  <span>Neo Tokyo, Net</span>
                </div>
                <div className="flex items-center gap-1">
                  <LinkIcon className="w-4 h-4 text-primary" />
                  <a href="#" className="hover:text-primary transition-colors">dah.social/kai</a>
                </div>
             </div>
          </div>

          {/* Stats */}
          <div className="flex gap-6 pt-4 md:pt-24">
             <div className="text-center">
                <p className="text-2xl font-bold font-display text-white">{currentUser.stats.followers}</p>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">Followers</p>
             </div>
             <div className="text-center">
                <p className="text-2xl font-bold font-display text-white">{currentUser.stats.following}</p>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">Following</p>
             </div>
             <div className="text-center">
                <p className="text-2xl font-bold font-display text-primary">{currentUser.stats.reputation}</p>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">Reputation</p>
             </div>
          </div>
        </div>

        {/* Content Grid (MySpace Style) */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-12">
           {/* Left Col */}
           <div className="space-y-6">
              {/* About / HTML Bio */}
              <Card className="glass-card border-primary/20">
                 <CardHeader className="border-b border-white/5 pb-3">
                    <CardTitle className="text-lg font-display text-primary">About Me</CardTitle>
                 </CardHeader>
                 <CardContent className="pt-4 text-sm leading-relaxed">
                    <div 
                      className="prose prose-invert prose-sm prose-p:my-2 prose-a:text-primary"
                      dangerouslySetInnerHTML={{ __html: currentUser.bio }} 
                    />
                    <div className="mt-4 flex flex-wrap gap-2">
                       {["Design", "Crypto", "Cyberpunk", "Music"].map(tag => (
                         <Badge key={tag} variant="secondary" className="bg-white/5 hover:bg-white/10">{tag}</Badge>
                       ))}
                    </div>
                 </CardContent>
              </Card>

              {/* Music Player Module */}
              <Card className="glass-card border-secondary/20 overflow-hidden">
                 <CardHeader className="bg-secondary/10 border-b border-secondary/20 pb-3">
                    <CardTitle className="text-lg font-display text-secondary flex items-center gap-2">
                      <Music className="w-5 h-5" />
                      Anthem
                    </CardTitle>
                 </CardHeader>
                 <CardContent className="p-4">
                    <div className="flex items-center gap-3 bg-black/40 p-3 rounded-lg border border-white/5">
                       <div className="w-10 h-10 bg-secondary rounded flex items-center justify-center">
                          <Music className="w-5 h-5 text-white animate-pulse" />
                       </div>
                       <div className="flex-1 overflow-hidden">
                          <p className="text-sm font-bold truncate">Midnight City</p>
                          <p className="text-xs text-muted-foreground">M83</p>
                       </div>
                       <div className="flex gap-1">
                          <div className="w-1 h-3 bg-primary animate-[bounce_1s_infinite]" />
                          <div className="w-1 h-5 bg-primary animate-[bounce_1.2s_infinite]" />
                          <div className="w-1 h-2 bg-primary animate-[bounce_0.8s_infinite]" />
                       </div>
                    </div>
                 </CardContent>
              </Card>
           </div>

           {/* Center/Right Main Content */}
           <div className="lg:col-span-2 space-y-6">
              <Tabs defaultValue="posts" className="w-full">
                <TabsList className="w-full bg-white/5 border border-white/10">
                  <TabsTrigger value="posts" className="flex-1">Posts</TabsTrigger>
                  <TabsTrigger value="media" className="flex-1">Media</TabsTrigger>
                  <TabsTrigger value="friends" className="flex-1">Top 8</TabsTrigger>
                </TabsList>

                <TabsContent value="posts" className="mt-6 space-y-4">
                   {/* Placeholder for Profile Posts */}
                   <div className="text-center py-10 text-muted-foreground border border-dashed border-white/10 rounded-xl">
                      <p>No recent updates from Kai.</p>
                   </div>
                </TabsContent>

                <TabsContent value="friends" className="mt-6">
                   <Card className="glass-card border-white/10">
                      <CardHeader>
                         <CardTitle className="font-display">Top Connections</CardTitle>
                      </CardHeader>
                      <CardContent>
                         <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            {users.concat(users).slice(0, 8).map((friend, i) => (
                               <div key={i} className="text-center group cursor-pointer">
                                  <div className="relative mb-2 mx-auto w-20 h-20">
                                     <Avatar className="w-full h-full border-2 border-white/10 group-hover:border-primary transition-colors">
                                        <AvatarImage src={friend.avatar} />
                                        <AvatarFallback>{friend.name[0]}</AvatarFallback>
                                     </Avatar>
                                     <div className="absolute -top-1 -right-1 w-6 h-6 bg-primary text-black font-bold rounded-full flex items-center justify-center text-xs">
                                        {i + 1}
                                     </div>
                                  </div>
                                  <p className="font-bold text-sm truncate group-hover:text-primary transition-colors">{friend.name}</p>
                                  <p className="text-xs text-muted-foreground">{friend.stats.reputation} REP</p>
                               </div>
                            ))}
                         </div>
                      </CardContent>
                   </Card>
                </TabsContent>
              </Tabs>
           </div>
        </div>
      </div>
    </div>
  );
}
