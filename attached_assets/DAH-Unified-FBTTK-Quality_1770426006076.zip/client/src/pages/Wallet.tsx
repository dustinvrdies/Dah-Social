import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ArrowUpRight, ArrowDownRight, Landmark, Clock, CheckCircle2 } from "lucide-react";

type Balance = { approvedCents: number; pendingCents: number; currency: string };
type LedgerRow = { id: string; sourceType: string; sourceId: string; amountCents: number; currency: string; status: string; reason?: string | null; createdAt: string; approvedAt?: string | null };

function fmtMoney(cents: number, currency = "USD") {
  const dollars = (cents / 100).toFixed(2);
  return currency === "USD" ? `$${dollars}` : `${dollars} ${currency}`;
}

export default function Wallet() {
  const balanceQ = useQuery<Balance>({
    queryKey: ["/api/earnings/balance"],
    queryFn: async () => {
      const r = await fetch("/api/earnings/balance", { credentials: "include" });
      if (!r.ok) throw new Error("Failed to load balance");
      return r.json();
    },
  });

  const ledgerQ = useQuery<{ ledger: LedgerRow[] }>({
    queryKey: ["/api/earnings/ledger"],
    queryFn: async () => {
      const r = await fetch("/api/earnings/ledger?limit=50", { credentials: "include" });
      if (!r.ok) throw new Error("Failed to load earnings ledger");
      return r.json();
    },
  });

  const currency = balanceQ.data?.currency ?? "USD";
  const approved = balanceQ.data?.approvedCents ?? 0;
  const pending = balanceQ.data?.pendingCents ?? 0;

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row gap-8 items-start justify-between">
        <div>
          <h1 className="text-4xl font-display font-bold neon-text-purple mb-2">Earnings</h1>
          <p className="text-muted-foreground">
            You only get paid for proven value—primarily qualified, capped ad engagement that looks native in-feed.
          </p>
        </div>
        <div className="flex gap-3">
          <Button className="bg-primary text-black font-bold hover:bg-primary/90 gap-2" disabled>
            <ArrowUpRight className="w-4 h-4" /> Payout
          </Button>
          <Button variant="secondary" className="gap-2" disabled>
            <ArrowDownRight className="w-4 h-4" /> Deposit
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="glass-card border-primary/20 bg-gradient-to-br from-primary/10 to-transparent">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Approved (Available)</CardTitle>
            <CardDescription>Spendable and eligible for payout.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-display font-bold neon-text-purple">{fmtMoney(approved, currency)}</div>
          </CardContent>
        </Card>

        <Card className="glass-card border-primary/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Pending Review</CardTitle>
            <CardDescription>Qualified, capped events waiting for review/settlement.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-display font-bold">{fmtMoney(pending, currency)}</div>
          </CardContent>
        </Card>

        <Card className="glass-card border-primary/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Payout Status</CardTitle>
            <CardDescription>Withdrawals are disabled until payout rails are configured.</CardDescription>
          </CardHeader>
          <CardContent className="flex items-center gap-3">
            <Landmark className="w-6 h-6 text-muted-foreground" />
            <div className="text-sm text-muted-foreground">Not configured</div>
          </CardContent>
        </Card>
      </div>

      <Card className="glass-card border-primary/20">
        <CardHeader>
          <CardTitle>Recent Earnings</CardTitle>
          <CardDescription>Server-verified ledger of proven earnings.</CardDescription>
        </CardHeader>
        <CardContent>
          {ledgerQ.isLoading || balanceQ.isLoading ? (
            <div className="text-sm text-muted-foreground">Loading…</div>
          ) : ledgerQ.isError || balanceQ.isError ? (
            <div className="text-sm text-red-400">Could not load earnings. Make sure you are logged in.</div>
          ) : (ledgerQ.data?.ledger?.length ?? 0) === 0 ? (
            <div className="text-sm text-muted-foreground">No earnings yet. Engage with sponsored content to qualify.</div>
          ) : (
            <div className="space-y-3">
              {ledgerQ.data!.ledger.map((row) => (
                <div key={row.id} className="flex items-center justify-between gap-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      {row.status === "approved" ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Clock className="w-4 h-4 text-amber-400" />
                      )}
                      <div className="font-medium truncate">
                        {row.reason ?? "earning"} <span className="text-muted-foreground">•</span>{" "}
                        <span className="text-muted-foreground truncate">{row.sourceType}:{row.sourceId}</span>
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {new Date(row.createdAt).toLocaleString()}
                    </div>
                  </div>
                  <div className="font-semibold tabular-nums">{fmtMoney(row.amountCents, row.currency)}</div>
                </div>
              ))}
              <Separator className="my-2" />
              <div className="text-xs text-muted-foreground">
                Anti-abuse: dedupe per day per ad, plus per-ad daily caps. Only qualified events accrue earnings.
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
