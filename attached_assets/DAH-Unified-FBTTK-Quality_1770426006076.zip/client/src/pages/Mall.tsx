import { products } from "@/lib/mockData";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Search, Filter, ShoppingCart, Tag, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Mall() {
  const { toast } = useToast();

  const handleBuy = (name: string, price: number) => {
    toast({
      title: "Purchase Successful!",
      description: `You bought ${name} for ${price} DAH.`,
      className: "bg-primary text-primary-foreground border-none",
    });
  };

  return (
    <div className="space-y-8 pb-10">
      {/* Hero Banner */}
      <div className="relative rounded-3xl overflow-hidden border border-white/10 h-[300px] flex items-center">
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent z-10" />
        <img 
          src="https://images.unsplash.com/photo-1555664424-778a69022365?w=1200&auto=format&fit=crop&q=80" 
          alt="Mall Hero" 
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="relative z-20 p-8 max-w-2xl">
           <Badge className="bg-primary text-black hover:bg-primary mb-4 font-bold">NEW DROP</Badge>
           <h1 className="text-4xl md:text-6xl font-display font-bold mb-4 neon-text-cyan">
             CYBER WEEK <br/> COLLECTION
           </h1>
           <p className="text-lg text-muted-foreground mb-6">
             Limited edition digital assets and physical merchandise available now. 
             Earn 2x coins on all purchases today.
           </p>
           <Button size="lg" className="bg-white text-black hover:bg-white/90 font-bold px-8">
             Shop Now
           </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between sticky top-20 z-30 bg-background/80 backdrop-blur-xl p-4 rounded-xl border border-white/5">
         <div className="relative w-full md:w-96">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search DAH Mall..." className="pl-10 bg-white/5 border-white/10" />
         </div>
         <div className="flex gap-2 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
            {["All", "Digital", "Physical", "Services", "Drops"].map((cat) => (
              <Button key={cat} variant="outline" className="border-white/10 hover:bg-white/5 hover:text-primary whitespace-nowrap">
                {cat}
              </Button>
            ))}
            <Button variant="ghost" size="icon">
               <Filter className="w-4 h-4" />
            </Button>
         </div>
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
         {products.concat(products).concat(products).map((product, i) => (
            <Card key={`${product.id}-${i}`} className="glass-card border-white/5 group hover:border-primary/50 transition-all duration-300">
               <div className="relative aspect-square overflow-hidden rounded-t-xl bg-white/5">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-2 right-2 flex flex-col gap-2">
                     <Badge variant="secondary" className="backdrop-blur-md bg-black/60">
                        {product.listingType}
                     </Badge>
                  </div>
                  {/* Quick Action Overlay */}
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 backdrop-blur-sm">
                     <Button size="icon" className="rounded-full bg-white text-black hover:bg-white/90" onClick={() => handleBuy(product.name, product.price)}>
                        <ShoppingCart className="w-5 h-5" />
                     </Button>
                     <Button size="icon" variant="secondary" className="rounded-full">
                        <Tag className="w-5 h-5" />
                     </Button>
                  </div>
               </div>
               <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                     <div>
                        <h3 className="font-bold truncate pr-2">{product.name}</h3>
                        <p className="text-xs text-muted-foreground">{product.category}</p>
                     </div>
                     <div className="text-right">
                        <p className="font-display font-bold text-primary">{product.price} DAH</p>
                        <p className="text-[10px] text-muted-foreground flex items-center justify-end gap-1">
                           <Clock className="w-3 h-3" /> 2h left
                        </p>
                     </div>
                  </div>
               </CardContent>
               <CardFooter className="p-4 pt-0 flex items-center justify-between text-xs text-muted-foreground border-t border-white/5 mt-auto">
                  <span className="flex items-center gap-1">
                     Seller: <span className="text-foreground hover:underline cursor-pointer">@SellerName</span>
                  </span>
                  <span>{product.likes} Likes</span>
               </CardFooter>
            </Card>
         ))}
      </div>
    </div>
  );
}
