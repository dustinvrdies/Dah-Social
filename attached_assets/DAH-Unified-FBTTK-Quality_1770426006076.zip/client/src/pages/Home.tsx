import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { useInfiniteQuery, useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Send } from "lucide-react";
import { FeedPostCard, type FeedPost } from "@/components/feed/FeedPostCard";
import { SponsoredAdCard, type FeedAd } from "@/components/feed/SponsoredAdCard";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/components/AuthProvider";

type PostsPage = { posts: FeedPost[]; nextCursor: string | null };
type AdsResponse = { ads: FeedAd[] };

function useIntersectionSentinel(onVisible: () => void) {
  const ref = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) onVisible();
      },
      { rootMargin: "400px" },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [onVisible]);
  return ref;
}

export default function Home() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [tab, setTab] = useState<"for-you" | "following">("for-you");
  const [draft, setDraft] = useState("");

  const postsQuery = useInfiniteQuery<PostsPage>({
    queryKey: [tab === "following" ? "/api/feed/following" : "/api/posts", { tab }],
    initialPageParam: null as string | null,
    queryFn: async ({ pageParam, queryKey }) => {
      const endpoint = queryKey[0] as string;
      const cursor = pageParam ? `&cursor=${encodeURIComponent(pageParam)}` : "";
      const res = await fetch(`${endpoint}?limit=20${cursor}`, { credentials: "include" });
      if (!res.ok) throw new Error(await res.text());
      return (await res.json()) as PostsPage;
    },
    getNextPageParam: (lastPage) => lastPage.nextCursor,
    staleTime: 10_000,
    gcTime: 5 * 60_000,
  });

  const adsQuery = useQuery<AdsResponse>({
    queryKey: ["/api/ads/feed"],
    queryFn: async () => {
      const res = await fetch("/api/ads/feed?limit=20", { credentials: "include" });
      if (!res.ok) throw new Error(await res.text());
      return (await res.json()) as AdsResponse;
    },
    staleTime: 60_000,
    gcTime: 10 * 60_000,
  });

  const mergedFeed = useMemo(() => {
    const pages = postsQuery.data?.pages ?? [];
    const posts = pages.flatMap((p) => p.posts);

    const ads = adsQuery.data?.ads ?? [];

    const out: Array<{ kind: "post"; post: FeedPost } | { kind: "ad"; ad: FeedAd }> = [];
    let adIdx = 0;
    for (let i = 0; i < posts.length; i++) {
      out.push({ kind: "post", post: posts[i] });
      if ((i + 1) % 7 === 0 && ads.length > 0) {
        out.push({ kind: "ad", ad: ads[adIdx % ads.length] });
        adIdx++;
      }
    }
    return out;
  }, [postsQuery.data, adsQuery.data]);

  const createPost = useMutation({
    mutationFn: async () => {
      const content = draft.trim();
      if (!content) throw new Error("Write something first.");
      await apiRequest("POST", "/api/posts", { content });
    },
    onSuccess: async () => {
      setDraft("");
      await queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/feed/following"] });
      toast({ title: "Posted", description: "Your post is live." });
    },
    onError: (err: any) => toast({ title: "Couldn’t post", description: String(err?.message ?? err), variant: "destructive" }),
  });

  const likeMutation = useMutation({
    mutationFn: async ({ postId, liked }: { postId: string; liked: boolean }) => {
      await apiRequest("POST", liked ? `/api/posts/${postId}/unlike` : `/api/posts/${postId}/like`);
    },
    onMutate: async ({ postId, liked }) => {
      const key = [tab === "following" ? "/api/feed/following" : "/api/posts", { tab }];
      await queryClient.cancelQueries({ queryKey: key });
      const prev = queryClient.getQueryData<any>(key);
      queryClient.setQueryData<any>(key, (data: any) => {
        if (!data) return data;
        return {
          ...data,
          pages: data.pages.map((pg: any) => ({
            ...pg,
            posts: pg.posts.map((p: FeedPost) => {
              if (p.id !== postId) return p;
              const nextLiked = !liked;
              return {
                ...p,
                likeCount: Math.max(0, p.likeCount + (nextLiked ? 1 : -1)),
                viewer: { ...(p.viewer ?? {}), liked: nextLiked },
              };
            }),
          })),
        };
      });
      return { prev, key };
    },
    onError: (_err, _vars, ctx) => {
      if (ctx?.prev) queryClient.setQueryData(ctx.key, ctx.prev);
    },
    onSettled: async (_d, _e, _v, ctx) => {
      if (ctx?.key) await queryClient.invalidateQueries({ queryKey: ctx.key });
    },
  });

  const recordAdEvent = useMutation({
    mutationFn: async (payload: { adId: string; type: "impression" | "click" | "view_time"; durationMs?: number }) => {
      await apiRequest("POST", "/api/ads/event", payload);
    },
    onError: () => {
      // Never block UX for telemetry.
    },
  });

  const onVisible = useCallback(() => {
    if (postsQuery.hasNextPage && !postsQuery.isFetchingNextPage) postsQuery.fetchNextPage();
  }, [postsQuery.hasNextPage, postsQuery.isFetchingNextPage, postsQuery.fetchNextPage]);

  const loadMoreRef = useIntersectionSentinel(onVisible);

  const isFollowingDisabled = !user;

  return (
    <div className="mx-auto w-full max-w-2xl space-y-4">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-xl font-semibold tracking-tight">Feed</h1>
        <Tabs value={tab} onValueChange={(v) => setTab(v as any)}>
          <TabsList>
            <TabsTrigger value="for-you">For you</TabsTrigger>
            <TabsTrigger value="following" disabled={isFollowingDisabled} title={isFollowingDisabled ? "Log in to see Following" : ""}>
              Following
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="text-sm font-medium">Create</div>
          <div className="text-xs text-muted-foreground">High-signal posts perform best. Quality beats volume.</div>
        </CardHeader>
        <CardContent className="pt-0">
          <Textarea value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Share an update…" className="min-h-[96px]" />
        </CardContent>
        <CardFooter className="flex justify-end gap-2">
          <Button onClick={() => createPost.mutate()} disabled={createPost.isPending || !draft.trim()} className="gap-2">
            {createPost.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            Post
          </Button>
        </CardFooter>
      </Card>

      {postsQuery.isLoading ? (
        <div className="flex items-center justify-center py-10 text-muted-foreground">
          <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Loading feed…
        </div>
      ) : postsQuery.isError ? (
        <Card>
          <CardContent className="p-4">
            <div className="font-medium">Couldn’t load feed</div>
            <div className="mt-1 text-sm text-muted-foreground">{String((postsQuery.error as any)?.message ?? postsQuery.error)}</div>
            <div className="mt-3">
              <Button variant="secondary" onClick={() => postsQuery.refetch()}>Try again</Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {mergedFeed.map((item, idx) => {
            if (item.kind === "ad") {
              return (
                <SponsoredAdCard
                  key={`ad-${item.ad.id}-${idx}`}
                  ad={item.ad}
                  onImpression={(adId) => recordAdEvent.mutate({ adId, type: "impression" })}
                  onClick={(adId) => recordAdEvent.mutate({ adId, type: "click" })}
                  onQualifiedView={(adId, durationMs) => recordAdEvent.mutate({ adId, type: "view_time", durationMs })}
                />
              );
            }
            return (
              <FeedPostCard
                key={`post-${item.post.id}`}
                post={item.post}
                onLike={(postId, liked) => likeMutation.mutate({ postId, liked })}
              />
            );
          })}

          <div ref={loadMoreRef} />

          {postsQuery.isFetchingNextPage ? (
            <div className="flex items-center justify-center py-6 text-muted-foreground">
              <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Loading more…
            </div>
          ) : postsQuery.hasNextPage ? null : (
            <div className="py-6 text-center text-sm text-muted-foreground">You’re all caught up.</div>
          )}
        </div>
      )}
    </div>
  );
}
