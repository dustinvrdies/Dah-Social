import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/toaster";
import { AppLayout } from "@/components/layout/AppLayout";

// Social feature providers
import { AuthProvider } from "@/components/AuthProvider";
import { EarningsEventListener } from "@/components/EarningsEventListener";
import { EnvironmentBadge } from "@/components/EnvironmentBadge";

// Platform core pages
import Home from "@/pages/Home";
import Wallet from "@/pages/Wallet";
import Profile from "@/pages/Profile";

// Social feature pages (lowercase filenames from Dah-Social)
import SocialHome from "@/pages/home";
import VideoPage from "@/pages/video";
import MallPage from "@/pages/mall";
import StorePage from "@/pages/store";
import ProfilePage from "@/pages/profile";
import NotificationsPage from "@/pages/notifications";
import LoginPage from "@/pages/login";
import InboxPage from "@/pages/inbox";
import LivePage from "@/pages/live";
import GroupsPage from "@/pages/groups";
import EventsPage from "@/pages/events";
import DiscoverPage from "@/pages/discover";
import QuestsPage from "@/pages/quests";
import DashboardPage from "@/pages/dashboard";
import AvenuesPage from "@/pages/avenues";
import AvenueDetailPage from "@/pages/avenue-detail";
import AvenuePostPage from "@/pages/avenue-post";
import TermsPage from "@/pages/terms";
import PrivacyPage from "@/pages/privacy";

import NotFound from "@/pages/not-found";

function Router() {
  return (
    <AppLayout>
      <Switch>
        {/* Platform shell routes */}
        <Route path="/" component={Home} />
        <Route path="/wallet" component={Wallet} />
        <Route path="/profile" component={Profile} />

        {/* Social feature routes */}
        <Route path="/social" component={SocialHome} />
        <Route path="/video" component={VideoPage} />
        <Route path="/mall" component={MallPage} />
        <Route path="/mall/store/:storeId" component={StorePage} />
        <Route path="/profile/:username" component={ProfilePage} />
        <Route path="/notifications" component={NotificationsPage} />
        <Route path="/inbox" component={InboxPage} />
        <Route path="/login" component={LoginPage} />
        <Route path="/live" component={LivePage} />
        <Route path="/groups" component={GroupsPage} />
        <Route path="/events" component={EventsPage} />
        <Route path="/discover" component={DiscoverPage} />
        <Route path="/quests" component={QuestsPage} />
        <Route path="/dashboard" component={DashboardPage} />
        <Route path="/avenues" component={AvenuesPage} />
        <Route path="/av/:name" component={AvenueDetailPage} />
        <Route path="/av/:name/post/:postId" component={AvenuePostPage} />
        <Route path="/terms" component={TermsPage} />
        <Route path="/privacy" component={PrivacyPage} />

        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <Toaster />
          <EarningsEventListener />
          <EnvironmentBadge env="dev" />
          <Router />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}
