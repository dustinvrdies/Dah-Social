export type TextPost = {
  id: string;
  type: "text";
  user: string;
  content: string;
  media?: string;
};

export type VideoPost = {
  id: string;
  type: "video";
  user: string;
  src: string;
  caption?: string;
};

export type ListingCategory = "flea-market" | "thrift-shop" | "electronics" | "exchange";

export type Store = {
  id: string;
  name: string;
  owner: string;
  description: string;
  avatar?: string;
  banner?: string;
  category: ListingCategory;
  rating: number;
  sales: number;
  featured: boolean;
};

export type ListingPost = {
  id: string;
  type: "listing";
  user: string;
  title: string;
  price: number;
  location?: string;
  media?: string;
  category?: ListingCategory;
  dropship?: boolean;
  condition?: "new" | "like-new" | "used" | "for-parts";
};

export type AdPost = {
  id: string;
  type: "ad";
  advertiser: string;
  headline: string;
  caption: string;
  media?: string;
  videoSrc?: string;
  cta: string;
  ctaUrl: string;
  impressions: number;
  clicks: number;
  revenue: number;
};

export type Post = TextPost | VideoPost | ListingPost | AdPost;
