import { lsGet, lsSet } from "./storage";

function isSSR() {
  return typeof window === "undefined";
}

export type AdFormat = "image" | "video" | "carousel" | "listing" | "story";

export type NativeAd = {
  id: string;
  type: "ad";
  format: AdFormat;
  advertiser: string;
  advertiserHandle: string;
  advertiserVerified: boolean;
  headline: string;
  caption: string;
  media?: string | null;
  mediaAlt?: string | null;
  videoSrc?: string | null;
  carouselImages?: string[] | null;
  cta: string;
  ctaUrl: string;
  // server-configured policy (optional on client)
  rewardCentsPerQualifiedView?: number;
  rewardCentsPerClick?: number;
  dailyUserCapCents?: number;
};

type LocalAdState = {
  viewedAds: Record<string, number>;
};

const KEY = "dah.ads.local";
const defaultLocalState: LocalAdState = { viewedAds: {} };

// Minimal fallback ads so the UI never breaks offline.
const fallbackAds: NativeAd[] = [
  {
    id: "fallback-1",
    type: "ad",
    format: "image",
    advertiser: "DAH",
    advertiserHandle: "dah",
    advertiserVerified: true,
    headline: "Sponsored",
    caption: "Ads are loading. This placeholder keeps the feed stable.",
    media: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=900",
    mediaAlt: "Placeholder",
    cta: "Explore",
    ctaUrl: "/",
  },
];

function getLocalState(): LocalAdState {
  if (isSSR()) return defaultLocalState;
  return lsGet<LocalAdState>(KEY, defaultLocalState);
}

function saveLocalState(state: LocalAdState) {
  lsSet(KEY, state);
}

let serverAdsCache: NativeAd[] | null = null;
let serverAdsLoadedAt = 0;
let inFlight: Promise<NativeAd[]> | null = null;

export async function initAdsFeed(limit = 25): Promise<NativeAd[]> {
  const now = Date.now();
  if (serverAdsCache && now - serverAdsLoadedAt < 1000 * 60 * 10) return serverAdsCache; // 10 min cache
  if (inFlight) return inFlight;

  inFlight = (async () => {
    try {
      const res = await fetch(`/api/ads/feed?limit=${encodeURIComponent(limit)}`, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to load ads");
      const data = await res.json();
      const ads = (data?.ads ?? []).map((a: any) => ({
        ...a,
        type: "ad",
        // normalize optional json field
        carouselImages: typeof a.carouselImages === "string" ? safeJsonParse(a.carouselImages) : a.carouselImages,
      })) as NativeAd[];

      serverAdsCache = ads.length ? ads : fallbackAds;
      serverAdsLoadedAt = Date.now();
      return serverAdsCache;
    } catch {
      serverAdsCache = fallbackAds;
      serverAdsLoadedAt = Date.now();
      return serverAdsCache;
    } finally {
      inFlight = null;
    }
  })();

  return inFlight;
}

function safeJsonParse(val: string): any {
  try { return JSON.parse(val); } catch { return null; }
}

export function getAds(): NativeAd[] {
  return serverAdsCache ?? fallbackAds;
}

export function getNextFeedAd(index: number): NativeAd | null {
  const ads = getAds().filter((a) => a.format === "image" || a.format === "listing" || a.format === "video");
  if (!ads.length) return null;
  return ads[index % ads.length];
}

export function hasUserSeenAd(adId: string): boolean {
  const state = getLocalState();
  return (state.viewedAds[adId] || 0) > 0;
}

function markSeen(adId: string) {
  if (isSSR()) return;
  const state = getLocalState();
  state.viewedAds[adId] = (state.viewedAds[adId] || 0) + 1;
  saveLocalState(state);
}

async function sendAdEvent(payload: { adId: string; type: "impression" | "click" | "view_time"; durationMs?: number }) {
  try {
    const res = await fetch("/api/ads/event", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(payload),
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (typeof window !== "undefined" && data?.credited) {
      window.dispatchEvent(new CustomEvent("dah:earning_credited", { detail: { amountCents: data.amountCents, currency: "USD", reason: data.reason } }));
    }
    return data;
  } catch {
    return null;
  }
}

// NOTE: These functions deliberately do NOT mint rewards client-side.
// The server decides what qualifies as a proven earning.
export function recordImpression(adId: string, _username: string) {
  markSeen(adId);
  void sendAdEvent({ adId, type: "impression" });
}

export function recordClick(adId: string, _username: string) {
  markSeen(adId);
  void sendAdEvent({ adId, type: "click" });
}

export function recordViewTime(adId: string, _username: string, durationMs: number) {
  // Only send meaningful durations to reduce noise.
  if (durationMs < 500) return;
  markSeen(adId);
  void sendAdEvent({ adId, type: "view_time", durationMs });
}
