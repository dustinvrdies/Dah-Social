export const currentUser = {
  id: "u1",
  handle: "@cypher_kai",
  name: "Kai",
  avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=60",
  cover: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=1200&auto=format&fit=crop&q=80",
  coins: 1450,
  isTeen: true, // Double earning logic
  collegeFund: 5000,
  bio: "Digital nomad drifting through the neon rain. <br/> <b>Design</b> | <i>Code</i> | <u>Life</u>",
  theme: "neon-cyan",
  stats: {
    followers: 1205,
    following: 450,
    reputation: 98
  }
};

export const users = [
  currentUser,
  {
    id: "u2",
    handle: "@neon_vixen",
    name: "Vixen",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=60",
    isTeen: false,
    stats: { followers: 8900, following: 120, reputation: 99 }
  },
  {
    id: "u3",
    handle: "@glitch_god",
    name: "Glitch",
    avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=400&auto=format&fit=crop&q=60",
    isTeen: true,
    stats: { followers: 450, following: 800, reputation: 85 }
  }
];

export const posts = [
  {
    id: "p1",
    authorId: "u2",
    content: "Just dropped a new collection in the Mall. Check it out before it's gone! 🛍️✨ #DigitalFashion #DAHMall",
    media: "https://images.unsplash.com/photo-1558470598-a5dda9640f6b?w=800&auto=format&fit=crop&q=80",
    likes: 245,
    comments: 12,
    timestamp: "2h ago"
  },
  {
    id: "p2",
    authorId: "u3",
    content: "Found this glitch in the matrix today... or maybe just a really cool wall art. 🤖",
    media: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80",
    likes: 89,
    comments: 4,
    timestamp: "4h ago"
  },
  {
    id: "p3",
    authorId: "u1",
    content: "Working on my new profile theme. Going for a retro-future vibe. Thoughts?",
    media: null,
    likes: 56,
    comments: 8,
    timestamp: "6h ago"
  }
];

export const products = [
  {
    id: "prod1",
    sellerId: "u2",
    name: "Cyberpunk Visor",
    price: 500,
    image: "https://images.unsplash.com/photo-1576435728678-35d0160d0137?w=400&auto=format&fit=crop&q=60",
    category: "Accessories",
    listingType: "Drop",
    likes: 120
  },
  {
    id: "prod2",
    sellerId: "u3",
    name: "Retro Console",
    price: 1200,
    image: "https://images.unsplash.com/photo-1551103782-8ab07afd45c1?w=400&auto=format&fit=crop&q=60",
    category: "Tech",
    listingType: "Flea Market",
    likes: 45
  },
  {
    id: "prod3",
    sellerId: "u1",
    name: "Neon Sign - Custom",
    price: 350,
    image: "https://images.unsplash.com/photo-1563245372-f21724e3856d?w=400&auto=format&fit=crop&q=60",
    category: "Decor",
    listingType: "Drop",
    likes: 230
  }
];
