export function isProduction() {
  return process.env.NODE_ENV === "production";
}

export function resolveDatabaseUrl(): string {
  if (process.env.DATABASE_URL && process.env.DATABASE_URL.trim().length > 0) {
    return process.env.DATABASE_URL;
  }

  const host = process.env.PGHOST;
  const port = process.env.PGPORT;
  const user = process.env.PGUSER;
  const password = process.env.PGPASSWORD;
  const database = process.env.PGDATABASE;

  if (host && port && user && database) {
    const auth = password
      ? `${encodeURIComponent(user)}:${encodeURIComponent(password)}`
      : `${encodeURIComponent(user)}`;
    return `postgresql://${auth}@${host}:${port}/${database}`;
  }

  throw new Error(
    [
      "Database configuration missing.",
      "",
      "Set DATABASE_URL, or (on Replit with Postgres enabled) ensure PGHOST/PGPORT/PGUSER/PGPASSWORD/PGDATABASE are present.",
    ].join("\n"),
  );
}
