import express, { type Request, Response, NextFunction } from "express";
import { createServer } from "http";
import path from "path";
import crypto from "crypto";
import { registerRoutes } from "./routes";
import { serveStatic } from "./static";
import { setupAuth } from "./auth";

const app = express();
const httpServer = createServer(app);

declare module "http" {
  interface IncomingMessage {
    rawBody: unknown;
  }
}

// --- Core middleware ---
app.disable("x-powered-by");

// Request ID for observability and trust/debuggability.
app.use((req, res, next) => {
  const id = (req.headers["x-request-id"] as string) || crypto.randomUUID();
  (req as any).requestId = id;
  res.setHeader("x-request-id", id);
  next();
});

// Security headers (minimal, dependency-free).
app.use((req, res, next) => {
  res.setHeader("x-content-type-options", "nosniff");
  res.setHeader("x-frame-options", "DENY");
  res.setHeader("referrer-policy", "strict-origin-when-cross-origin");
  res.setHeader("permissions-policy", "camera=(), microphone=(), geolocation=()");
  next();
});

app.use(
  express.json({
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    },
    limit: "1mb",
  }),
);
app.use(express.urlencoded({ extended: false, limit: "1mb" }));

setupAuth(app);

// Static uploads (user-generated content). Ensure this stays separate from app static.
app.use("/uploads", express.static(path.resolve(process.cwd(), "uploads"), { fallthrough: true }));

export function log(message: string, source = "express") {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

  console.log(`${formattedTime} [${source}] ${message}`);
}

// API access log (avoid leaking full JSON bodies).
app.use((req, res, next) => {
  const start = Date.now();
  const reqId = (req as any).requestId as string | undefined;

  res.on("finish", () => {
    if (!req.path.startsWith("/api")) return;
    const duration = Date.now() - start;
    log(`${req.method} ${req.path} ${res.statusCode} in ${duration}ms${reqId ? ` (reqId=${reqId})` : ""}`);
  });

  next();
});

(async () => {
  await registerRoutes(httpServer, app);

  // Global error handler.
  app.use((err: any, req: Request, res: Response, _next: NextFunction) => {
    const status = err?.status || err?.statusCode || 500;
    const message = err?.message || "Internal Server Error";

    if (res.headersSent) return;

    const reqId = (req as any).requestId as string | undefined;

    // Log minimally in production, more detail in development.
    if (process.env.NODE_ENV !== "production") {
      console.error("API error:", {
        status,
        message,
        path: req.path,
        method: req.method,
        reqId,
        stack: err?.stack,
      });
    } else {
      console.error("API error:", { status, message, path: req.path, method: req.method, reqId });
    }

    res.status(status).json({ ok: false, error: { message, status, requestId: reqId } });
  });

  // Serve client.
  if (process.env.NODE_ENV === "production") {
    serveStatic(app);
  } else {
    const { setupVite } = await import("./vite");
    await setupVite(httpServer, app);
  }

  const port = parseInt(process.env.PORT || "5000", 10);
  httpServer.listen(
    {
      port,
      host: "0.0.0.0",
      reusePort: true,
    },
    () => {
      log(`serving on port ${port}`);
    },
  );
})();
