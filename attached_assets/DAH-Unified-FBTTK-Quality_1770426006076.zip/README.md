# DAH Unified (Platform UI + Social Features)

This repository combines the **DAH-Platform** look-and-feel with the full feature set from **Dah-Social**.

## Stack
- **Client:** React + Vite + TypeScript + Tailwind
- **Server:** Express (TypeScript)
- **DB/ORM:** Postgres + Drizzle

## Run on Replit (Free Tier)

1. **Enable Postgres** (recommended)
   - In Replit, add the Postgres module (or ensure it is already enabled).
   - The app will use Replit-provided `PG*` env vars automatically. You do **not** need to set `DATABASE_URL` on Replit.

2. **Set secrets (optional but recommended)**
   - In Replit Secrets, set:
     - `SESSION_SECRET` (recommended)

3. **Run**
   - The project is configured so the Replit Run button executes:
     - `npm run dev`

## Local development

1. Install
```bash
npm install
```

2. Configure environment
- Copy `.env.example` → `.env`
- Set either `DATABASE_URL` or Postgres env vars

3. Run
```bash
npm run dev
```

## Database
Apply schema (Drizzle):
```bash
npm run db:push
```

## Build & start (production)
```bash
npm run build
npm start
```


## Native Ads + Proven Earnings

DAH uses **native in-feed ads**. Engagement events (impression / view-time / click) are recorded server-side, but **earnings only accrue for qualified, deduped, capped events** (e.g., a view-time of at least 3 seconds or a click), and only for authenticated users.

- Ads feed: `GET /api/ads/feed`
- Record ad event: `POST /api/ads/event`
- Earnings balance: `GET /api/earnings/balance`
- Earnings ledger: `GET /api/earnings/ledger`

To enable DB on Replit, add the Postgres module and set `DATABASE_URL` (or rely on `PGHOST/PGUSER/PGPASSWORD/PGPORT/PGDATABASE`).

## Health and smoke check

After pressing **Run**, open `/api/health` in the preview to confirm the server is up.

## Proven ad-earnings model

This project only credits earnings for **qualified ad engagement** (server-verified):
- **Qualified view**: view-time ≥ 3 seconds (with ≥50% visibility on the client)
- **Qualified click**: click event

Raw engagement events are recorded, but only qualified events create entries in the `earnings_ledger`.

## Environment variables

Copy `.env.example` to `.env` and set values as needed. On Replit with Postgres enabled, the app can also use the built-in `PGHOST/PGUSER/PGPASSWORD/PGPORT/PGDATABASE` variables automatically.



## Trust & Security Notes
- Authentication uses server-backed sessions (HttpOnly cookies) via Passport + express-session.
- Earnings are credited only by the server after qualified, capped ad engagement (client never mints rewards).
- Each API response includes an `x-request-id` header to support debugging and audit trails.


## Feed quality upgrades

- Home feed now uses server-backed pagination (`/api/posts` and `/api/feed/following`) with React Query infinite loading.
- Native sponsored content is interleaved from `/api/ads/feed` and tracked via `/api/ads/event` using proven-engagement rules on the server.
