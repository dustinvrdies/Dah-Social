-- Ads + Earnings (proven-value ad engagement)
CREATE TABLE IF NOT EXISTS "ads" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  "format" text NOT NULL,
  "advertiser" text NOT NULL,
  "advertiser_handle" text NOT NULL,
  "advertiser_verified" boolean NOT NULL DEFAULT false,
  "headline" text NOT NULL,
  "caption" text NOT NULL,
  "media" text,
  "media_alt" text,
  "video_src" text,
  "carousel_images" text,
  "cta" text NOT NULL,
  "cta_url" text NOT NULL,
  "is_active" boolean NOT NULL DEFAULT true,
  "reward_cents_per_qualified_view" integer NOT NULL DEFAULT 1,
  "reward_cents_per_click" integer NOT NULL DEFAULT 5,
  "daily_user_cap_cents" integer NOT NULL DEFAULT 50,
  "created_at" timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS "ads_active_idx" ON "ads" ("is_active");
CREATE INDEX IF NOT EXISTS "ads_created_at_idx" ON "ads" ("created_at");

CREATE TABLE IF NOT EXISTS "ad_events" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  "ad_id" varchar NOT NULL REFERENCES "ads" ("id") ON DELETE cascade,
  "user_id" varchar REFERENCES "users" ("id") ON DELETE set null,
  "type" text NOT NULL,
  "duration_ms" integer,
  "dedupe_key" text NOT NULL,
  "created_at" timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS "ad_events_ad_id_idx" ON "ad_events" ("ad_id");
CREATE INDEX IF NOT EXISTS "ad_events_user_id_idx" ON "ad_events" ("user_id");
CREATE INDEX IF NOT EXISTS "ad_events_created_at_idx" ON "ad_events" ("created_at");
CREATE UNIQUE INDEX IF NOT EXISTS "ad_events_user_dedupe_idx" ON "ad_events" ("user_id", "dedupe_key");

CREATE TABLE IF NOT EXISTS "earnings_ledger" (
  "id" varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  "user_id" varchar NOT NULL REFERENCES "users" ("id") ON DELETE cascade,
  "source_type" text NOT NULL,
  "source_id" varchar NOT NULL,
  "amount_cents" integer NOT NULL,
  "currency" text NOT NULL DEFAULT 'USD',
  "status" text NOT NULL DEFAULT 'pending',
  "reason" text,
  "created_at" timestamptz NOT NULL DEFAULT now(),
  "approved_at" timestamptz
);

CREATE INDEX IF NOT EXISTS "earnings_user_id_idx" ON "earnings_ledger" ("user_id");
CREATE INDEX IF NOT EXISTS "earnings_status_idx" ON "earnings_ledger" ("status");
CREATE INDEX IF NOT EXISTS "earnings_created_at_idx" ON "earnings_ledger" ("created_at");
