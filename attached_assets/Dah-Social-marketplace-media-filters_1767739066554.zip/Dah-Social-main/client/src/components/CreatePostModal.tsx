import { useState } from "react";
import { useAuth } from "./AuthProvider";
import { addCoins } from "@/lib/dahCoins";
import { pushNotification } from "@/lib/notifications";
import type { TextPost } from "@/lib/postTypes";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { createPost } from "@/lib/postsApi";
import { uploadFiles, type UploadedFile } from "@/lib/uploadsApi";
import { ImagePlus, Video, X } from "lucide-react";

export function CreatePostModal({
  disabled,
  onCreated,
}: {
  disabled?: boolean;
  onCreated?: (p: TextPost) => void;
}) {
  const { session } = useAuth();
  const [open, setOpen] = useState(false);
  const [content, setContent] = useState("");
  const [attachments, setAttachments] = useState<UploadedFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const canSubmit = content.trim().length >= 1 && content.trim().length <= 2000;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button disabled={disabled} variant="secondary">
          Post
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create a post</DialogTitle>
        </DialogHeader>

        <div className="space-y-3">
          <Textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="What are you building today?" />

          {err && <div className="text-sm text-red-400">{err}</div>}


<div className="mt-2 flex flex-col gap-2">
  <div className="flex items-center gap-2">
    <label className="inline-flex cursor-pointer items-center gap-2 rounded-md border border-border/60 bg-background px-3 py-2 text-sm hover:bg-accent/40">
      <ImagePlus className="h-4 w-4" />
      Add photos/videos
      <input
        type="file"
        className="hidden"
        multiple
        accept="image/*,video/mp4,video/webm,video/quicktime"
        onChange={async (e) => {
          const files = Array.from(e.target.files || []);
          if (!files.length) return;
          setUploading(true);
          setErr(null);
          try {
            const uploaded = await uploadFiles(files);
            setAttachments((cur) => [...cur, ...uploaded].slice(0, 12));
          } catch (ex: any) {
            setErr(ex?.message || "Upload failed");
          } finally {
            setUploading(false);
            e.currentTarget.value = "";
          }
        }}
      />
    </label>

    {uploading && <div className="text-sm text-muted-foreground">Uploading…</div>}
    <div className="text-xs text-muted-foreground ml-auto">
      Max 25MB per file, up to 12 files.
    </div>
  </div>

  {attachments.length > 0 && (
    <div className="grid grid-cols-3 gap-2">
      {attachments.map((a, i) => (
        <div key={a.url} className="relative overflow-hidden rounded-lg border border-border/50 bg-muted/20">
          {a.type === "image" ? (
            <img src={a.url} className="h-24 w-full object-cover" />
          ) : (
            <video src={a.url} className="h-24 w-full object-cover" muted playsInline />
          )}
          <button
            type="button"
            className="absolute right-1 top-1 rounded bg-background/80 p-1 hover:bg-background"
            onClick={() => setAttachments((cur) => cur.filter((_, idx) => idx !== i))}
            aria-label="Remove attachment"
          >
            <X className="h-3 w-3" />
          </button>
        </div>
      ))}
    </div>
  )}
</div>

          <Button
            disabled={!session || !canSubmit || uploading}
            onClick={async () => {
              if (!session) return;
              setErr(null);
              try {
                const res = await createPost(content.trim());
                const p: TextPost = {
                  id: res.post.id,
                  type: "text",
                  user: res.post.username,
                  content: res.post.content,
                  createdAt: res.post.createdAt,
                  likeCount: res.post.likeCount ?? 0,
                  commentCount: res.post.commentCount ?? 0,
                  viewerLiked: res.post.viewer?.liked ?? false,
                  displayName: res.post.profile?.displayName ?? null,
                  avatarUrl: res.post.profile?.avatarUrl ?? null,
                };
                addCoins(session.user.username, "Created a post", 2);
                pushNotification({
                  title: "Post created",
                  message: "Your post is now live in the feed.",
                });
                onCreated?.(p);
                setContent("");
                setOpen(false);
              } catch (e: any) {
                setErr(e?.message || "Could not create post");
              }
            }}
          >
            Publish
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
