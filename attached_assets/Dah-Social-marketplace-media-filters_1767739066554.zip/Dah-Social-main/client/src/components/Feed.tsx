import { useEffect, useMemo, useState } from "react";
import { useAuth } from "./AuthProvider";
import { initialFeed } from "@/lib/feedData";
import { getHidden } from "@/lib/moderation";
import { Post, AdPost, TextPost } from "@/lib/postTypes";
import { getAds } from "@/lib/ads";
import { PostRenderer } from "./PostRenderer";
import { CreatePostModal } from "./CreatePostModal";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sparkles, Users } from "lucide-react";
import { listPosts, listFollowingPosts, listBookmarkedPosts } from "@/lib/postsApi";

function mapApiToText(p: any): TextPost {
  return {
    id: p.id,
    type: "text",
    user: p.username,
    content: p.content,
    createdAt: p.createdAt,
    likeCount: p.likeCount ?? 0,
    commentCount: p.commentCount ?? 0,
    viewerLiked: p.viewer?.liked ?? false,
    viewerBookmarked: p.viewer?.bookmarked ?? false,
    media: p.media ?? [],
    displayName: p.profile?.displayName ?? null,
    avatarUrl: p.profile?.avatarUrl ?? null,
  };
}

export function Feed({ mode = "forYou" }: { mode?: "forYou" | "following" | "saved" }) {
  const { session } = useAuth();
  const [tab, setTab] = useState<"for-you" | "following">("for-you");

const [query, setQuery] = useState("");
const [sort, setSort] = useState<"new" | "top">("new");
const [hasMedia, setHasMedia] = useState(false);

  const [remotePosts, setRemotePosts] = useState<TextPost[]>([]);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    let mounted = true;
    (async () => {
      setIsLoading(true);
      try {
        const res = await listPosts(30, undefined, { q: query || undefined, sort, hasMedia: hasMedia ? true : undefined });
        if (!mounted) return;
        setRemotePosts(res.posts.map(mapApiToText));
        setNextCursor(res.nextCursor);
      } catch {
        // If API is not ready (e.g., DB not initialized), fall back to demo feed.
        if (!mounted) return;
        setRemotePosts([]);
        setNextCursor(null);
      } finally {
        if (mounted) setIsLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [session?.user?.id]);

  const hidden = useMemo(() => new Set(getHidden(session?.user.username ?? "guest")), [session?.user.username]);

  const baseFeed: (Post | AdPost)[] = useMemo(() => {
    const ads = getAds();
    const server = remotePosts.filter((p) => !hidden.has(p.id));
    const demo = initialFeed.filter((p: any) => !hidden.has(p.id));

    // Prefer server posts when available; otherwise show demo.
    const primary: (Post | AdPost)[] = server.length ? (server as any) : (demo as any);

    // Insert ads every ~6 items.
    const out: (Post | AdPost)[] = [];
    let adIdx = 0;
    for (let i = 0; i < primary.length; i++) {
      out.push(primary[i]);
      if ((i + 1) % 6 === 0 && adIdx < ads.length) {
        out.push(ads[adIdx++]);
      }
    }
    return out;
  }, [remotePosts, hidden]);

  const canPost = !!session;

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between">
        <Tabs value={tab} onValueChange={(v) => setTab(v as any)}>
          <TabsList>
            <TabsTrigger value="for-you" className="gap-2">
              <Sparkles className="h-4 w-4" /> For You
            </TabsTrigger>
            <TabsTrigger value="following" className="gap-2">
              <Users className="h-4 w-4" /> Following
            </TabsTrigger>
          </TabsList>
        
</Tabs>

        <div className="mt-3 flex flex-col gap-2 rounded-xl border border-border/50 bg-card/50 p-3">
          <div className="flex items-center gap-2">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search posts…"
              className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"
            />
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value === "top" ? "top" : "new")}
              className="h-9 rounded-md border border-input bg-background px-2 text-sm"
            >
              <option value="new">Newest</option>
              <option value="top">Top</option>
            </select>
          </div>
          <label className="flex items-center gap-2 text-sm text-muted-foreground">
            <input
              type="checkbox"
              checked={hasMedia}
              onChange={(e) => setHasMedia(e.target.checked)}
            />
            Only posts with media
          </label>
          <div className="text-xs text-muted-foreground">
            Tip: after changing filters, pull to refresh or scroll to reload.
          </div>
        </div>

        <CreatePostModal disabled={!canPost} onCreated={(p) => setRemotePosts((cur) => [p, ...cur])} />
      </div>

      {!session && (
        <div className="text-sm text-muted-foreground border border-border/50 rounded-lg p-3">
          You are viewing as a guest. Log in to create posts, like, follow, and customize your profile.
        </div>
      )}

      {isLoading && <div className="text-sm text-muted-foreground">Loading feed…</div>}

      <div className="space-y-4">
        {baseFeed.map((p) => (
          <PostRenderer key={p.id} post={p as any} />
        ))}
      </div>

      {nextCursor && (
        <button
          className="w-full text-sm text-muted-foreground hover:text-foreground border border-border/50 rounded-lg p-3"
          onClick={async () => {
            const res = await listPosts(30, nextCursor);
            setRemotePosts((cur) => [...cur, ...res.posts.map(mapApiToText)]);
            setNextCursor(res.nextCursor);
          }}
        >
          Load more
        </button>
      )}
    </div>
  );
}
