import { fetchJson } from "./api";

export type ApiNotification = {
  id: string;
  toUserId: string;
  fromUserId: string | null;
  type: string;
  entityType: string;
  entityId: string;
  message: string;
  isRead: boolean;
  createdAt: string;
};

export async function listNotifications(limit = 50, cursor?: string) {
  const q = new URLSearchParams();
  q.set("limit", String(limit));
  if (cursor) q.set("cursor", cursor);
  return fetchJson<{ notifications: ApiNotification[]; nextCursor: string | null }>(`/api/notifications?${q.toString()}`);
}

export async function markNotificationRead(id: string) {
  return fetchJson<{ ok: boolean }>(`/api/notifications/${id}/read`, { method: "POST" });
}

export async function markAllNotificationsRead() {
  return fetchJson<{ ok: true; count: number }>(`/api/notifications/read-all`, { method: "POST" });
}
