import { fetchJson } from "./api";

export type ApiPost = {
  media?: { url: string; type: "image" | "video" }[];
  id: string;
  userId: string;
  content: string;
  createdAt: string;
  username: string;
  profile: { displayName?: string | null; avatarUrl?: string | null } | null;
  likeCount: number;
  commentCount: number;
  viewer?: { liked: boolean; bookmarked?: boolean };
};

export async function listPosts(limit = 30, cursor?: string, filters?: { q?: string; sort?: "new" | "top"; hasMedia?: boolean }) {
  const q = new URLSearchParams();
  q.set("limit", String(limit));
  if (cursor) q.set("cursor", cursor);
  if (filters?.q) q.set("q", filters.q);
  if (filters?.sort) q.set("sort", filters.sort);
  if (typeof filters?.hasMedia === "boolean") q.set("hasMedia", filters.hasMedia ? "1" : "0");
  return fetchJson<{ posts: ApiPost[]; nextCursor: string | null }>(`/api/posts?${q.toString()}`, { method: "GET" });
}

export async function createPost(content: string, media?: { url: string; type: "image" | "video" }[]) {
  return fetchJson<{ post: ApiPost }>("/api/posts", {
    method: "POST",
    body: JSON.stringify({ content, media }),
  });
}


export async function likePost(postId: string) {
  return fetchJson<{ ok: true }>(`/api/posts/${postId}/like`, { method: "POST" });
}

export async function unlikePost(postId: string) {
  return fetchJson<{ ok: true }>(`/api/posts/${postId}/unlike`, { method: "POST" });
}


export async function listFollowingPosts(limit = 30, cursor?: string) {
  const q = new URLSearchParams();
  q.set("limit", String(limit));
  if (cursor) q.set("cursor", cursor);
  if (filters?.q) q.set("q", filters.q);
  if (filters?.sort) q.set("sort", filters.sort);
  if (typeof filters?.hasMedia === "boolean") q.set("hasMedia", filters.hasMedia ? "1" : "0");
  const url = `/api/feed/following?${q.toString()}`;
  return fetchJson<{ posts: ApiPost[]; nextCursor: string | null }>(url);
}

export async function bookmarkPost(postId: string) {
  return fetchJson<{ ok: true }>(`/api/posts/${postId}/bookmark`, { method: "POST" });
}

export async function unbookmarkPost(postId: string) {
  return fetchJson<{ ok: true }>(`/api/posts/${postId}/unbookmark`, { method: "POST" });
}

export async function listBookmarkedPosts(limit = 30, cursor?: string) {
  const q = new URLSearchParams();
  q.set("limit", String(limit));
  if (cursor) q.set("cursor", cursor);
  if (filters?.q) q.set("q", filters.q);
  if (filters?.sort) q.set("sort", filters.sort);
  if (typeof filters?.hasMedia === "boolean") q.set("hasMedia", filters.hasMedia ? "1" : "0");
  const url = `/api/bookmarks?${q.toString()}`;
  return fetchJson<{ posts: ApiPost[]; nextCursor: string | null }>(url);
}
