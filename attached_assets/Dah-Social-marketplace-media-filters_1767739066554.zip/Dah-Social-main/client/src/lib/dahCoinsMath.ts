export function calculateDahCoins(base: number) {
  const b = Math.max(0, Math.floor(base));
  return { available: b, lockedForCollege: 0 };
}
