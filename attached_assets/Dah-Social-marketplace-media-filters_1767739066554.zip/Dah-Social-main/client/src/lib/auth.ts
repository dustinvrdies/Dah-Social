import { fetchJson } from "./api";

export type SessionUser = {
  id: string;
  username: string;
};

export type Session = {
  user: SessionUser;
};

export async function getSession(): Promise<Session | null> {
  try {
    const res = await fetchJson<{ user: SessionUser }>("/api/auth/me", { method: "GET" });
    return { user: res.user };
  } catch {
    return null;
  }
}

export async function register(username: string, password: string): Promise<Session> {
  const res = await fetchJson<{ user: SessionUser }>("/api/auth/register", {
    method: "POST",
    body: JSON.stringify({ username, password }),
  });
  return { user: res.user };
}

export async function login(username: string, password: string): Promise<Session> {
  const res = await fetchJson<{ user: SessionUser }>("/api/auth/login", {
    method: "POST",
    body: JSON.stringify({ username, password }),
  });
  return { user: res.user };
}

export async function logout(): Promise<void> {
  await fetchJson<{ ok: true }>("/api/auth/logout", { method: "POST" });
}
