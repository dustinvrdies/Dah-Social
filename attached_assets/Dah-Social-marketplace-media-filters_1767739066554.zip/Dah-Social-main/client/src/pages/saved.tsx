import { MainNav } from "@/components/MainNav";
import { Feed } from "@/components/Feed";
import { useAuth } from "@/components/AuthProvider";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function SavedPage() {
  const { session, isLoading } = useAuth();

  if (!isLoading && !session) {
    return (
      <main className="min-h-screen bg-background text-foreground">
        <MainNav />
        <div className="max-w-2xl mx-auto p-6">
          <h1 className="text-xl font-semibold mb-2">Saved</h1>
          <p className="text-muted-foreground mb-4">Log in to view your saved posts.</p>
          <Link href="/login"><Button>Log in</Button></Link>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-background text-foreground">
      <MainNav />
      <div className="max-w-2xl mx-auto">
        <div className="p-4">
          <h1 className="text-xl font-semibold mb-3">Saved</h1>
          <Feed mode="saved" />
        </div>
      </div>
    </main>
  );
}
