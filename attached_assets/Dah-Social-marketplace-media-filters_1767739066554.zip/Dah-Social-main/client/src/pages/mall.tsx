import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MainNav } from "@/components/MainNav";
import { MallLanding } from "@/components/MallLanding";
import { ListingCard } from "@/components/ListingCard";
import { CreateListingModal } from "@/components/CreateListingModal";
import { listListings } from "@/lib/listingsApi";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Grid2X2, List, SlidersHorizontal } from "lucide-react";

const categories = [
  { value: "", label: "All categories" },
  { value: "electronics", label: "Electronics" },
  { value: "fashion", label: "Fashion" },
  { value: "home", label: "Home" },
  { value: "collectibles", label: "Collectibles" },
  { value: "services", label: "Services" },
  { value: "vehicles", label: "Vehicles" },
  { value: "flea-market", label: "Flea Market" },
  { value: "trade", label: "Trade" },
  { value: "other", label: "Other" },
];

export default function MallPage() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [showFilters, setShowFilters] = useState(false);

  const [q, setQ] = useState("");
  const [category, setCategory] = useState("");
  const [condition, setCondition] = useState("");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [sort, setSort] = useState<"new" | "price-asc" | "price-desc">("new");
  const [hasMedia, setHasMedia] = useState(false);

  const filters = useMemo(() => {
    const minPriceCents = minPrice ? Math.max(0, Math.round(Number(minPrice) * 100)) : undefined;
    const maxPriceCents = maxPrice ? Math.max(0, Math.round(Number(maxPrice) * 100)) : undefined;

    return {
      q: q || undefined,
      category: category || undefined,
      condition: condition || undefined,
      minPriceCents: Number.isFinite(minPriceCents as any) ? minPriceCents : undefined,
      maxPriceCents: Number.isFinite(maxPriceCents as any) ? maxPriceCents : undefined,
      sort,
      hasMedia: hasMedia ? true : undefined,
    };
  }, [q, category, condition, minPrice, maxPrice, sort, hasMedia]);

  const { data, isLoading, refetch } = useQuery({
    queryKey: ["listings", filters],
    queryFn: () => listListings(60, undefined, filters),
  });

  const listings = data?.listings ?? [];

  return (
    <main className="min-h-screen bg-background text-foreground">
      <MainNav />

      <div className="mx-auto max-w-5xl">
        <div className="border-b border-border/50">
          <MallLanding />
        </div>

        <div className="p-4">
          <div className="mb-3 flex flex-col gap-3 rounded-2xl border border-border/50 bg-card/40 p-4">
            <div className="flex flex-col gap-2 md:flex-row md:items-center">
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search marketplace… (title, description)"
                className="md:max-w-md"
              />

              <div className="flex items-center gap-2 md:ml-auto">
                <Button variant="secondary" className="gap-2" onClick={() => setShowFilters((s) => !s)}>
                  <SlidersHorizontal className="h-4 w-4" />
                  Filters
                </Button>

                <Button
                  variant={viewMode === "grid" ? "secondary" : "ghost"}
                  size="icon"
                  className="h-9 w-9"
                  onClick={() => setViewMode("grid")}
                >
                  <Grid2X2 className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "secondary" : "ghost"}
                  size="icon"
                  className="h-9 w-9"
                  onClick={() => setViewMode("list")}
                >
                  <List className="h-4 w-4" />
                </Button>

                <CreateListingModal onCreated={() => refetch()} />
              </div>
            </div>

            {showFilters && (
              <div className="grid gap-3 md:grid-cols-5">
                <div className="grid gap-1">
                  <div className="text-xs text-muted-foreground">Category</div>
                  <select className="h-9 rounded-md border border-input bg-background px-2 text-sm" value={category} onChange={(e) => setCategory(e.target.value)}>
                    {categories.map((c) => (
                      <option key={c.value} value={c.value}>{c.label}</option>
                    ))}
                  </select>
                </div>

                <div className="grid gap-1">
                  <div className="text-xs text-muted-foreground">Condition</div>
                  <select className="h-9 rounded-md border border-input bg-background px-2 text-sm" value={condition} onChange={(e) => setCondition(e.target.value)}>
                    <option value="">Any</option>
                    <option value="new">new</option>
                    <option value="like-new">like-new</option>
                    <option value="used">used</option>
                    <option value="for-parts">for-parts</option>
                  </select>
                </div>

                <div className="grid gap-1">
                  <div className="text-xs text-muted-foreground">Min price</div>
                  <Input value={minPrice} onChange={(e) => setMinPrice(e.target.value)} inputMode="decimal" placeholder="0" />
                </div>

                <div className="grid gap-1">
                  <div className="text-xs text-muted-foreground">Max price</div>
                  <Input value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} inputMode="decimal" placeholder="9999" />
                </div>

                <div className="grid gap-1">
                  <div className="text-xs text-muted-foreground">Sort</div>
                  <select className="h-9 rounded-md border border-input bg-background px-2 text-sm" value={sort} onChange={(e) => setSort(e.target.value as any)}>
                    <option value="new">Newest</option>
                    <option value="price-asc">Price: low to high</option>
                    <option value="price-desc">Price: high to low</option>
                  </select>

                  <label className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
                    <input type="checkbox" checked={hasMedia} onChange={(e) => setHasMedia(e.target.checked)} />
                    Only listings with photos/videos
                  </label>
                </div>
              </div>
            )}
          </div>

          {isLoading && <div className="text-sm text-muted-foreground">Loading listings…</div>}

          {!isLoading && listings.length === 0 && (
            <div className="rounded-2xl border border-border/50 bg-card/30 p-6 text-sm text-muted-foreground">
              No listings yet. Create the first one to make the marketplace feel alive.
            </div>
          )}

          <div className={viewMode === "grid" ? "grid grid-cols-2 gap-3 md:grid-cols-3" : "grid gap-3"}>
            {listings.map((l) => (
              <ListingCard
                key={l.id}
                user={l.username}
                title={l.title}
                price={Math.round((l.priceCents ?? 0) / 100)}
                location={l.location || "Local pickup / delivery"}
                media={l.media && l.media.length ? l.media : ""}
                category={l.category}
                viewMode={viewMode}
                postId={l.id}
              />
            ))}
          </div>

          <div className="mt-6 text-xs text-muted-foreground">
            Marketplace is in beta. Report suspicious behavior and always use safe payment methods.
          </div>
        </div>
      </div>
    </main>
  );
}
