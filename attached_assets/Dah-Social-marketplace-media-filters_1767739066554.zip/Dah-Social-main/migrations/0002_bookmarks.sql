-- 0002_bookmarks.sql
-- Adds bookmarks (saved posts).

CREATE TABLE IF NOT EXISTS "bookmarks" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  "user_id" uuid NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "post_id" uuid NOT NULL REFERENCES "posts"("id") ON DELETE CASCADE,
  "created_at" timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS "bookmarks_user_post_uq" ON "bookmarks" ("user_id","post_id");
CREATE INDEX IF NOT EXISTS "bookmarks_user_id_idx" ON "bookmarks" ("user_id");
CREATE INDEX IF NOT EXISTS "bookmarks_post_id_idx" ON "bookmarks" ("post_id");
CREATE INDEX IF NOT EXISTS "bookmarks_created_at_idx" ON "bookmarks" ("created_at");
