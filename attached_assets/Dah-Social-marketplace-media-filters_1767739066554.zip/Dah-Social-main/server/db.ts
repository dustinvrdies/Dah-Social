import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "@shared/schema";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL is required. Provision a Postgres DB and set DATABASE_URL.");
}

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  // In some hosted environments, SSL is required. Replit Postgres typically works without forcing SSL.
  // If you need SSL, set PGSSLMODE=require or DATABASE_URL with sslmode.
});

export const db = drizzle(pool, { schema });
