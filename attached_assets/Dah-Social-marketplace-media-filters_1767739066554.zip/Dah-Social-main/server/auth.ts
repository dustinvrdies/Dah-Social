import type { Express, RequestHandler } from "express";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import PgSession from "connect-pg-simple";
import { pool } from "./db";
import { storage } from "./storage";
import { hashPassword, verifyPassword } from "./password";

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface User {
      id: string;
      username: string;
    }
  }
}

export function setupAuth(app: Express) {

const secret =
  process.env.SESSION_SECRET ||
  (process.env.NODE_ENV !== "production"
    ? "dev-insecure-session-secret-change-me"
    : undefined);

if (!secret) {
  // Replit: set SESSION_SECRET in Secrets.
  throw new Error("SESSION_SECRET is required in production. Set it in your environment secrets.");
}


  const PgStore = PgSession(session);

  app.set("trust proxy", 1);

  app.use(
    session({
      store: new PgStore({
        pool,
        createTableIfMissing: true,
        tableName: "user_sessions",
      }),
      secret,
      resave: false,
      saveUninitialized: false,
      cookie: {
        httpOnly: true,
        sameSite: "lax",
        secure: process.env.NODE_ENV === "production",
        maxAge: 1000 * 60 * 60 * 24 * 30, // 30 days
      },
    }),
  );

  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) return done(null, false, { message: "Invalid username or password" });
        if (!verifyPassword(password, user.passwordHash)) {
          return done(null, false, { message: "Invalid username or password" });
        }
        return done(null, { id: user.id, username: user.username });
      } catch (e) {
        return done(e);
      }
    }),
  );

  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: string, done) => {
    try {
      const user = await storage.getUserById(id);
      if (!user) return done(null, false);
      return done(null, { id: user.id, username: user.username });
    } catch (e) {
      return done(e);
    }
  });
}

export const requireAuth: RequestHandler = (req, res, next) => {
  if (req.isAuthenticated && req.isAuthenticated()) return next();
  return res.status(401).json({ message: "Unauthorized" });
};

export async function registerUser(username: string, password: string) {
  const existing = await storage.getUserByUsername(username);
  if (existing) {
    const err = new Error("Username already taken");
    (err as any).statusCode = 409;
    throw err;
  }
  const passwordHash = hashPassword(password);
  const user = await storage.createUser(username, passwordHash);
  return { id: user.id, username: user.username };
}
