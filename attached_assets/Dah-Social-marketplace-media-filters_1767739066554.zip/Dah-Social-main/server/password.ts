import { randomBytes, scryptSync, timingSafeEqual } from "crypto";

/**
 * Password hashing using Node's built-in scrypt.
 * Stored format: scrypt$<N,r,p>$<salt_b64>$<dk_b64>
 */
const SCRYPT_PARAMS = { N: 1 << 15, r: 8, p: 1 } as const; // reasonable default

function b64(buf: Buffer) {
  return buf.toString("base64");
}
function fromB64(s: string) {
  return Buffer.from(s, "base64");
}

export function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const dk = scryptSync(password, salt, 64, SCRYPT_PARAMS);
  const params = `${SCRYPT_PARAMS.N},${SCRYPT_PARAMS.r},${SCRYPT_PARAMS.p}`;
  return `scrypt$${params}$${b64(salt)}$${b64(dk)}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [algo, params, saltB64, dkB64] = stored.split("$");
    if (algo !== "scrypt") return false;
    const [N, r, p] = params.split(",").map((n) => parseInt(n, 10));
    if (![N, r, p].every((n) => Number.isFinite(n) && n > 0)) return false;

    const salt = fromB64(saltB64);
    const expected = fromB64(dkB64);
    const actual = scryptSync(password, salt, expected.length, { N, r, p });
    return timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}
