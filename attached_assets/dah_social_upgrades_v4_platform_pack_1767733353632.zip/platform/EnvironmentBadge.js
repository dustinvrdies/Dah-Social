export default function EnvironmentBadge({ env = "prod" }) {
  const color = env === "prod" ? "#16a34a" : env === "staging" ? "#f59e0b" : "#ef4444";
  return (
    <div style={{
      position: "fixed",
      bottom: 10,
      left: 10,
      padding: "4px 8px",
      borderRadius: 8,
      background: color,
      color: "#000",
      fontSize: 12,
      zIndex: 9999
    }}>
      {env.toUpperCase()}
    </div>
  );
}
