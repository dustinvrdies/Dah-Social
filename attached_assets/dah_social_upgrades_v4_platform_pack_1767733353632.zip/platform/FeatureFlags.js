export const flags = {
  subscriptions: true,
  escrow: true,
  messaging: true,
  analytics: true,
};

export function isEnabled(key) {
  return Boolean(flags[key]);
}
