import "../shared/ui.css";

export default function GatedPostNotice() {
  return (
    <div className="dah-card">
      <strong>Subscriber-only</strong>
      <div className="dah-muted">Subscribe to unlock this post.</div>
      <button className="dah-btn dah-btn-primary">Subscribe</button>
    </div>
  );
}
