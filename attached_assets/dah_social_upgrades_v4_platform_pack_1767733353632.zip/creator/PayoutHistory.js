import "../shared/ui.css";

export default function PayoutHistory({ rows = [] }) {
  return (
    <div className="dah-card">
      <strong>Payout History</strong>
      <div className="dah-divider" />
      {rows.length === 0 && <div className="dah-muted">No payouts yet.</div>}
      {rows.map(r => (
        <div key={r.id} className="dah-row" style={{ justifyContent: "space-between" }}>
          <span>{r.date}</span>
          <span>${r.amount}</span>
        </div>
      ))}
    </div>
  );
}
