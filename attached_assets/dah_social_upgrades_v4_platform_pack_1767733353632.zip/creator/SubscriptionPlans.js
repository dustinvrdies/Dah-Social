import "../shared/ui.css";

export default function SubscriptionPlans() {
  return (
    <div className="dah-card">
      <strong>Subscriptions</strong>
      <div className="dah-muted">Offer monthly support tiers to followers.</div>
      <button className="dah-btn dah-btn-primary">Create plan</button>
    </div>
  );
}
