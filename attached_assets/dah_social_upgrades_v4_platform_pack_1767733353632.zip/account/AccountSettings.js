import "../shared/ui.css";

export default function AccountSettings() {
  return (
    <div className="dah-card">
      <strong>Account Settings</strong>
      <div className="dah-divider" />
      <button className="dah-btn">Change email</button>
      <button className="dah-btn">Change password</button>
      <button className="dah-btn">Delete account</button>
    </div>
  );
}
