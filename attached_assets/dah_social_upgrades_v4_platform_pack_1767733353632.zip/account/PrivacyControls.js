import "../shared/ui.css";

export default function PrivacyControls() {
  return (
    <div className="dah-card">
      <strong>Privacy</strong>
      <div className="dah-divider" />
      <label><input type="checkbox" /> Public profile</label>
      <label><input type="checkbox" /> Allow DMs</label>
      <label><input type="checkbox" /> Show activity status</label>
    </div>
  );
}
