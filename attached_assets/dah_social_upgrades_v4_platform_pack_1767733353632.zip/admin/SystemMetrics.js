import "../shared/ui.css";

export default function SystemMetrics() {
  return (
    <div className="dah-card">
      <strong>System Metrics</strong>
      <div>API latency</div>
      <div>Error rate</div>
      <div>Active users</div>
    </div>
  );
}
