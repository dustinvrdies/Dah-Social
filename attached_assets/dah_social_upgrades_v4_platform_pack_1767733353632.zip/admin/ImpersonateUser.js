import "../shared/ui.css";

export default function ImpersonateUser() {
  return (
    <div className="dah-card">
      <strong>Impersonate User</strong>
      <input className="dah-input" placeholder="User ID" />
      <button className="dah-btn">Start session</button>
    </div>
  );
}
