DAH SOCIAL – UPGRADES PACK v4 (Platform & Scale)

This is a LARGE, feasible upgrade pack meant to push DAH Social from
"feature-rich app" to "scalable platform".

Everything here is:
- Frontend-first (React)
- Incremental
- Safe to add without breaking existing flows
- Designed to plug into real APIs later

================================================
WHAT’S INCLUDED
================================================

A. PLATFORM FOUNDATIONS
- feature flags
- environment config
- health/status UI
- audit logging hooks

B. AUTH & ACCOUNT CONTROL
- account settings panel
- sessions & device management (UI)
- privacy controls
- data export request UI

C. CREATOR ECONOMY
- subscriptions UI
- gated posts (paywall)
- revenue breakdown tables
- payout history

D. MARKETPLACE SCALE
- order history
- seller dashboard
- listing performance metrics
- automated safety checks (UI)

E. TRUST, SAFETY & COMPLIANCE
- KYC status UI (stub)
- risk flags
- dispute escalation
- transparency reports (UI)

F. GROWTH & RETENTION
- onboarding flows
- feature announcements
- re-engagement nudges
- streaks & milestones

G. ADMIN / OPS
- system metrics dashboard
- user impersonation (UI gate)
- content takedown logs
- config editor (UI only)

================================================
INTEGRATION
================================================
Add folders incrementally. Nothing is required to be wired all at once.
Use this pack to move DAH Social into “real platform” territory.
