import "../shared/ui.css";

export default function OnboardingChecklist({ steps = [] }) {
  return (
    <div className="dah-card">
      <strong>Getting Started</strong>
      <ul>
        {steps.map(s => <li key={s}>{s}</li>)}
      </ul>
    </div>
  );
}
