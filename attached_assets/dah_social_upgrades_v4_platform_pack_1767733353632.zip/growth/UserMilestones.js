import "../shared/ui.css";

export default function UserMilestones({ milestones = [] }) {
  return (
    <div className="dah-card">
      <strong>Milestones</strong>
      {milestones.map(m => <div key={m}>{m}</div>)}
    </div>
  );
}
