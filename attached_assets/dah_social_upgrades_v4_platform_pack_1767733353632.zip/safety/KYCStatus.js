import "../shared/ui.css";

export default function KYCStatus({ status = "unverified" }) {
  return (
    <div className="dah-card">
      <strong>Identity Verification</strong>
      <div className="dah-divider" />
      <div>Status: {status}</div>
      {status !== "verified" && <button className="dah-btn">Verify identity</button>}
    </div>
  );
}
