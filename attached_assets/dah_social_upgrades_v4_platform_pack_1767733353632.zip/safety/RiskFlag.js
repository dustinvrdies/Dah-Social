export default function RiskFlag({ level = "low" }) {
  const color = level === "high" ? "#ef4444" : level === "medium" ? "#f59e0b" : "#16a34a";
  return <span style={{ color }}>Risk: {level}</span>;
}
