import "../shared/ui.css";

export default function SellerDashboard() {
  return (
    <div className="dah-card">
      <strong>Seller Dashboard</strong>
      <div className="dah-divider" />
      <div>Total listings</div>
      <div>Sales this month</div>
      <div>Disputes</div>
    </div>
  );
}
