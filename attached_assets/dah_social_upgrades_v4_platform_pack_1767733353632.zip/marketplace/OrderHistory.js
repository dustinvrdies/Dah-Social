import "../shared/ui.css";

export default function OrderHistory({ orders = [] }) {
  return (
    <div className="dah-card">
      <strong>Orders</strong>
      <div className="dah-divider" />
      {orders.map(o => (
        <div key={o.id} className="dah-row" style={{ justifyContent: "space-between" }}>
          <span>{o.item}</span>
          <span>{o.status}</span>
        </div>
      ))}
    </div>
  );
}
