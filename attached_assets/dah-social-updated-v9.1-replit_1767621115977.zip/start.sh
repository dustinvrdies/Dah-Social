#!/usr/bin/env bash
npm install
npm run dev
