import MainNav from "../../components/MainNav";
import PostRenderer from "../../components/PostRenderer";
import { videoOnlyFeed } from "../../lib/feedData";

export default function VideoPage() {
  return (
    <main className="min-h-screen bg-black text-white">
      <MainNav />
      <div className="max-w-3xl mx-auto p-6 space-y-4">
        <h1 className="text-2xl font-bold">Video</h1>
        {videoOnlyFeed.map((p) => (
          <PostRenderer key={p.id} post={p as any} />
        ))}
      </div>
    </main>
  );
}
