"use client";

import { useEffect, useState } from "react";
import MainNav from "../../components/MainNav";
import { useAuth } from "../../components/AuthProvider";
import { getNotifications, Notification } from "../../lib/notifications";

export default function NotificationsPage() {
  const { session } = useAuth();
  const [list, setList] = useState<Notification[]>([]);

  useEffect(() => {
    if (!session) return;
    setList(getNotifications(session.username));
  }, [session]);

  return (
    <main className="min-h-screen bg-black text-white">
      <MainNav />
      <div className="max-w-3xl mx-auto p-6 space-y-4">
        <h1 className="text-2xl font-bold">Alerts</h1>
        {!session ? (
          <div className="text-neutral-400">Login to view alerts.</div>
        ) : list.length ? (
          <div className="space-y-2">
            {list.map((n) => (
              <div key={n.id} className="bg-neutral-950 border border-neutral-800 rounded-xl p-3">
                <div className="text-sm">{n.message}</div>
                <div className="text-xs text-neutral-500">{new Date(n.ts).toLocaleString()}</div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-neutral-400">No alerts yet.</div>
        )}
      </div>
    </main>
  );
}
