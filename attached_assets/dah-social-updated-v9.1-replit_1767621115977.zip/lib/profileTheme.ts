export type ProfileTheme = {
  background: string;
  accent: string; // tailwind class for text
  accentHex?: string; // CSS variable for global accent
  text: string;
  card: string;
  font: string;
};

export const defaultTheme: ProfileTheme = {
  background: "bg-black",
  accent: "text-purple-400",
  accentHex: "#7c3aed",
  text: "text-white",
  card: "bg-neutral-950",
  font: "font-sans",
};
