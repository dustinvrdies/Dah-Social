import os

STRUCTURE = {
    "apps/web": ["README.md"],
    "apps/api": ["README.md"],
    "scripts": ["dev.ps1"]
}

for folder, files in STRUCTURE.items():
    os.makedirs(folder, exist_ok=True)
    for f in files:
        path = os.path.join(folder, f)
        if not os.path.exists(path):
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(f"# {f}\n")

print("Dah Social scaffold created.")