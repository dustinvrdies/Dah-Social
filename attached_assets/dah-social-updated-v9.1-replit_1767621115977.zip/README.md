# DAH Social (v9)

Adds core social platform behaviors on top of v8:

- Following system (localStorage)
- Feed modes: All / Video / Mall / Following
- Basic moderation: Hide + Report (localStorage reports)
- Notifications/alerts center (localStorage)
- Profile follow button + reputation display

Everything remains local-only (no backend yet), free-tier friendly.

## Run
```bash
npm install
npm run dev
```

## Routes
- `/` Feed + modes + create
- `/video` Video view
- `/mall` Mall view
- `/profile/[username]` Profile (follow + theme)
- `/login` Local login
- `/notifications` Alerts center


## Replit
1. Upload this ZIP into a new Replit (Node.js / Next.js).
2. Replit should auto-run via `.replit`:
   - `npm install`
   - `npm run dev`
3. Open the webview for the running app.

If Replit prompts for a port, use **3000**.

### Expected routes
- `/`
- `/video`
- `/mall`
- `/profile/[username]`
- `/login`
- `/notifications`
