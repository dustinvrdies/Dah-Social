"use client";

import Link from "next/link";
import { useAuth } from "./AuthProvider";
import NotificationBell from "./NotificationBell";

const Item = ({ href, label }: { href: string; label: string }) => (
  <Link href={href} className="px-3 py-2 rounded hover:bg-neutral-900 text-sm">
    {label}
  </Link>
);

export default function MainNav() {
  const { session } = useAuth();

  return (
    <div className="sticky top-0 z-50 bg-black/90 backdrop-blur border-b border-neutral-800">
      <div className="max-w-3xl mx-auto flex items-center justify-between p-3 gap-2">
        <Link href="/" className="font-bold text-[color:var(--dah-accent)]">DAH</Link>

        <div className="flex gap-1 items-center">
          <Item href="/" label="Feed" />
          <Item href="/video" label="Video" />
          <Item href="/mall" label="Mall" />
          <Item href={session ? `/profile/${session.username}` : "/profile/dah"} label="Profile" />
          <NotificationBell />
          <Item href="/login" label={session ? `@${session.username}` : "Login"} />
        </div>
      </div>
    </div>
  );
}
