
'use client';
import { useState } from 'react';

export default function Comments() {
  const [comments, setComments] = useState<string[]>([]);
  const [input, setInput] = useState('');

  return (
    <div className="mt-2 text-sm">
      {comments.map((c, i) => (
        <div key={i} className="bg-neutral-800 p-2 rounded mb-1">{c}</div>
      ))}
      <input
        className="w-full p-2 bg-neutral-900 border border-neutral-700 rounded"
        placeholder="Add a comment"
        value={input}
        onChange={e => setInput(e.target.value)}
        onKeyDown={e => {
          if (e.key === 'Enter' && input.trim()) {
            setComments([...comments, input]);
            setInput('');
          }
        }}
      />
    </div>
  );
}
