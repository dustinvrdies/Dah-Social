const categories = [
  { title: "Flea Market", subtitle: "Local exchange and used goods" },
  { title: "Thrift Shop", subtitle: "Secondhand finds" },
  { title: "Electronics", subtitle: "Devices, parts, gear" },
  { title: "Exchange", subtitle: "Trade requests and swaps" },
];

export default function MallLanding() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">DAH Mall</h1>
      <p className="text-neutral-400">
        Social marketplace. Listings show up in your feed. Coins trading is disabled for safety.
      </p>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {categories.map((c) => (
          <div
            key={c.title}
            className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 hover:bg-neutral-900 cursor-pointer"
          >
            <div className="font-semibold">{c.title}</div>
            <div className="text-xs text-neutral-400 mt-1">{c.subtitle}</div>
          </div>
        ))}
      </div>

      <div className="text-sm text-neutral-500">
        Store auto-generation (based on user demand) will be added in a later iteration.
      </div>
    </div>
  );
}
