"use client";

import { useEffect, useMemo, useState } from "react";
import PostRenderer from "./PostRenderer";
import { initialFeed } from "../lib/feedData";
import { Post } from "../lib/postTypes";
import { addPost, getPosts, setPosts } from "../lib/posts";
import CreatePostModal from "./CreatePostModal";
import { useAuth } from "./AuthProvider";
import { addCoins } from "../lib/dahCoins";
import WalletSummary from "./WalletSummary";
import { getHidden } from "../lib/moderation";
import { getFollowing } from "../lib/follows";

type Mode = "all" | "following" | "video" | "mall";

export default function Feed() {
  const { session } = useAuth();
  const [posts, setPostsState] = useState<Post[]>([]);
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<Mode>("all");

  useEffect(() => {
    setPostsState(getPosts(initialFeed));
  }, []);

  const create = (post: Post) => {
    const updated = addPost(post, initialFeed);
    setPostsState(updated);
    if (session) addCoins(session.username, session.age, "Created a post", 2);
  };

  const reset = () => {
    setPosts(initialFeed);
    setPostsState(initialFeed);
  };

  const visiblePosts = useMemo(() => {
    const all = posts;
    if (!session) {
      if (mode === "video") return all.filter(p => p.type === "video");
      if (mode === "mall") return all.filter(p => p.type === "listing");
      return all;
    }

    const hidden = new Set(getHidden(session.username));
    let list = all.filter(p => !hidden.has(p.id));

    if (mode === "video") list = list.filter(p => p.type === "video");
    if (mode === "mall") list = list.filter(p => p.type === "listing");
    if (mode === "following") {
      const following = new Set(getFollowing(session.username));
      list = list.filter(p => following.has(p.user));
    }
    return list;
  }, [posts, session, mode]);

  const headerRight = useMemo(() => {
    if (!session) return null;
    return (
      <button onClick={() => setOpen(true)}
        className="px-4 py-2 rounded-xl bg-[color:var(--dah-accent)] text-black font-semibold">
        Create
      </button>
    );
  }, [session]);

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-2xl font-bold">Feed</div>
          <div className="text-sm text-neutral-400">Mixed posts: text, video, and DAH Mall listings.</div>
        </div>
        {headerRight}
      </div>

      <div className="flex flex-wrap gap-2 text-sm">
        <ModeBtn active={mode==="all"} onClick={()=>setMode("all")}>All</ModeBtn>
        <ModeBtn active={mode==="video"} onClick={()=>setMode("video")}>Video</ModeBtn>
        <ModeBtn active={mode==="mall"} onClick={()=>setMode("mall")}>Mall</ModeBtn>
        <ModeBtn active={mode==="following"} onClick={()=>setMode("following")} disabled={!session}>Following</ModeBtn>
      </div>

      <WalletSummary />

      <div className="text-xs text-neutral-500 flex justify-between">
        <span>{visiblePosts.length} items</span>
        <button onClick={reset} className="hover:underline">Reset demo content</button>
      </div>

      {visiblePosts.map((post) => (
        <PostRenderer key={post.id} post={post} />
      ))}

      <CreatePostModal open={open} onClose={() => setOpen(false)} onCreate={create} />
    </div>
  );
}

function ModeBtn({ active, onClick, children, disabled }: { active: boolean; onClick: ()=>void; children:any; disabled?: boolean }) {
  return (
    <button disabled={disabled} onClick={onClick}
      className={`px-3 py-1 rounded-xl border ${active ? "border-[color:var(--dah-accent)]" : "border-neutral-800"} bg-neutral-950 hover:bg-neutral-900 disabled:opacity-40`}>
      {children}
    </button>
  );
}
