"use client";
import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { getSession, setSession, Session } from "../lib/auth";
type CtxT = { session: Session | null; login: (u:string,a:number)=>void; logout: ()=>void };
const Ctx = createContext<CtxT | null>(null);
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setS] = useState<Session | null>(null);
  useEffect(()=>setS(getSession()),[]);
  const v = useMemo(()=>({ session,
    login:(u,a)=>{ const s={username:u.trim().toLowerCase(),age:a}; setSession(s); setS(s); },
    logout:()=>{ setSession(null); setS(null); }
  }),[session]);
  return <Ctx.Provider value={v}>{children}</Ctx.Provider>;
}
export const useAuth=()=>{ const c=useContext(Ctx); if(!c) throw new Error("useAuth"); return c; }
