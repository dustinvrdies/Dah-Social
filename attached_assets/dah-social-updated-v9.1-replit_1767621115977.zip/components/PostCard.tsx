"use client";
import { useState } from "react";
import Comments from "./Comments";
import { useAuth } from "./AuthProvider";
import { addCoins } from "../lib/dahCoins";
import { hidePost, reportPost } from "../lib/moderation";
import { pushNotification } from "../lib/notifications";

export default function PostCard({ user, content, postId }: { user: string; content: string; postId?: string }) {
  const { session } = useAuth();
  const [likes, setLikes] = useState(0);
  const [showComments, setShowComments] = useState(false);
  const [hidden, setHidden] = useState(false);

  const like = () => {
    setLikes((v) => v + 1);
    if (session) addCoins(session.username, session.age, "Liked a post", 1);
  };

  const toggleComments = () => {
    setShowComments((v) => !v);
    if (session) addCoins(session.username, session.age, "Engaged with comments", 1);
  };

  const doHide = () => {
    if (!session || !postId) return;
    hidePost(session.username, postId);
    setHidden(true);
  };

  const doReport = () => {
    if (!session || !postId) return;
    reportPost(session.username, postId, "user_report");
    pushNotification(session.username, { username: session.username, type: "system", message: "Report submitted. Thanks for helping keep DAH safe." });
  };

  if (hidden) {
    return (
      <div className="bg-neutral-950 border border-neutral-800 p-4 rounded-xl text-sm text-neutral-400">
        Post hidden.
      </div>
    );
  }

  return (
    <div className="bg-neutral-950 border border-neutral-800 p-4 rounded-xl space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div className="font-semibold">@{user}</div>
        {session ? (
          <div className="flex gap-2 text-xs">
            <button onClick={doHide} className="px-2 py-1 rounded bg-neutral-900 hover:bg-neutral-800">Hide</button>
            <button onClick={doReport} className="px-2 py-1 rounded bg-neutral-900 hover:bg-neutral-800">Report</button>
          </div>
        ) : null}
      </div>

      <p className="text-neutral-100 whitespace-pre-wrap">{content}</p>

      <div className="flex gap-3 text-sm">
        <button onClick={like} className="px-3 py-1 rounded bg-neutral-900 hover:bg-neutral-800">
          ❤️ {likes}
        </button>
        <button onClick={toggleComments} className="px-3 py-1 rounded bg-neutral-900 hover:bg-neutral-800">
          💬 Comment
        </button>
        <button
          onClick={() => navigator?.clipboard?.writeText?.(content)}
          className="px-3 py-1 rounded bg-neutral-900 hover:bg-neutral-800"
        >
          🔗 Share
        </button>
      </div>

      {showComments ? <Comments /> : null}
    </div>
  );
}
