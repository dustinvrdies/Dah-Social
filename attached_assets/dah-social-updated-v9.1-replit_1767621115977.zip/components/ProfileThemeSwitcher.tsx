import { ProfileTheme } from "../lib/profileTheme";

export default function ProfileThemeSwitcher({
  setTheme,
}: {
  setTheme: (theme: ProfileTheme) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2 mt-4 text-sm">
      <button
        className="px-3 py-1 rounded bg-neutral-900 hover:bg-neutral-800"
        onClick={() =>
          setTheme({
            background: "bg-black",
            accent: "text-purple-400",
            accentHex: "#7c3aed",
            text: "text-white",
            card: "bg-neutral-950",
            font: "font-sans",
          })
        }
      >
        Dark
      </button>

      <button
        className="px-3 py-1 rounded bg-neutral-900 hover:bg-neutral-800"
        onClick={() =>
          setTheme({
            background: "bg-white",
            accent: "text-blue-600",
            accentHex: "#2563eb",
            text: "text-black",
            card: "bg-neutral-100",
            font: "font-serif",
          })
        }
      >
        Light
      </button>

      <button
        className="px-3 py-1 rounded bg-neutral-900 hover:bg-neutral-800"
        onClick={() =>
          setTheme({
            background: "bg-black",
            accent: "text-emerald-400",
            accentHex: "#34d399",
            text: "text-white",
            card: "bg-neutral-950",
            font: "font-sans",
          })
        }
      >
        Emerald
      </button>
    </div>
  );
}
