"use client";

import { useEffect, useState } from "react";
import { useAuth } from "./AuthProvider";
import { getReputation, recordVerifiedSale } from "../lib/reputation";
import { addCoins } from "../lib/dahCoins";
import { pushNotification } from "../lib/notifications";

export default function ListingCard({
  user,
  title,
  price,
  location,
}: {
  user: string;
  title: string;
  price: number;
  location?: string;
}) {
  const { session } = useAuth();
  const [rep, setRep] = useState<{ score: number; verifiedSales: number } | null>(null);

  useEffect(() => {
    setRep(getReputation(user));
  }, [user]);

  const canMarkSold = session?.username === user;

  const markSold = () => {
    if (!session) return;
    const updated = recordVerifiedSale(session.username);
    setRep(updated);
    addCoins(session.username, session.age, "Verified sale", 20);
    pushNotification(session.username, { username: session.username, type: "sale", message: "Verified sale recorded. DAH Coins awarded." });
  };

  return (
    <div className="border border-neutral-800 rounded-xl p-4 bg-neutral-950 space-y-2">
      <div className="text-sm text-neutral-400">@{user} listed</div>
      <div className="font-semibold">{title}</div>
      <div className="flex items-center justify-between">
        <div className="text-[color:var(--dah-accent)] font-bold">${price}</div>
        {location ? <div className="text-xs text-neutral-400">{location}</div> : null}
      </div>

      <div className="text-xs text-neutral-500">
        Seller rep: {rep ? `${rep.score} (sales ${rep.verifiedSales})` : "—"}
      </div>

      {canMarkSold ? (
        <button onClick={markSold} className="px-3 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-sm">
          Mark as sold (demo)
        </button>
      ) : null}

      <div className="text-xs text-neutral-600">
        Payments and coin trading are disabled at this stage for safety and fraud prevention.
      </div>
    </div>
  );
}
