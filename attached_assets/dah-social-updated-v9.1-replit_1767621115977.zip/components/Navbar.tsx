import Link from "next/link";

export default function Navbar() {
  return (
    <nav className="flex justify-between items-center p-4 border-b border-zinc-800 bg-black text-white">
      <Link href="/" className="font-bold text-purple-400">DAH Social</Link>
      <div className="flex gap-4 text-sm">
        <Link href="/">Feed</Link>
        <Link href="/profile/dah">Profile</Link>
      </div>
    </nav>
  );
}
