"use client";
import { useRef } from "react";

export default function VideoPost({ src, user, caption }: { src: string; user: string; caption?: string }) {
  const ref = useRef<HTMLVideoElement>(null);

  const toggle = async () => {
    if (!ref.current) return;
    if (ref.current.paused) await ref.current.play();
    else ref.current.pause();
  };

  return (
    <div className="relative w-full h-[70vh] bg-black rounded-xl overflow-hidden border border-neutral-800">
      <video
        ref={ref}
        src={src}
        className="w-full h-full object-cover"
        loop
        muted
        playsInline
        onClick={toggle}
      />
      <div className="absolute bottom-3 left-3 space-y-1">
        <div className="font-semibold">@{user}</div>
        {caption ? <div className="text-sm text-neutral-200/90">{caption}</div> : null}
        <div className="text-xs text-neutral-400">Tap video to play/pause</div>
      </div>
    </div>
  );
}
