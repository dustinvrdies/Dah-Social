import { ReactNode } from "react";
import { ProfileTheme } from "../lib/profileTheme";

export default function ProfileThemeProvider({
  theme,
  children,
}: {
  theme: ProfileTheme;
  children: ReactNode;
}) {
  const style = {
    ["--dah-accent" as any]: theme.accentHex || "#7c3aed",
  };

  return (
    <div style={style} className={`min-h-screen ${theme.background} ${theme.text} ${theme.font}`}>
      {children}
    </div>
  );
}
