"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useAuth } from "./AuthProvider";
import { getNotifications } from "../lib/notifications";

export default function NotificationBell() {
  const { session } = useAuth();
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!session) return;
    const list = getNotifications(session.username);
    // simple unread model: count last 10 (we can add read markers later)
    setCount(list.slice(0, 10).length);
  }, [session]);

  if (!session) return null;

  return (
    <Link href="/notifications" className="relative px-3 py-2 rounded hover:bg-neutral-900 text-sm">
      Alerts
      {count > 0 ? (
        <span className="absolute -top-1 -right-1 text-xs bg-[color:var(--dah-accent)] text-black rounded-full px-2 py-[1px]">
          {count}
        </span>
      ) : null}
    </Link>
  );
}
