"use client";
import { useEffect, useState } from "react";
import { useAuth } from "./AuthProvider";
import { getWallet, getLedger, Wallet, Entry } from "../lib/dahCoins";
export default function WalletSummary(){
  const { session } = useAuth(); const [w,setW]=useState<Wallet|null>(null); const [l,setL]=useState<Entry[]>([]);
  useEffect(()=>{ if(!session) return; setW(getWallet(session.username)); setL(getLedger().filter(e=>e.username===session.username).slice(0,10)); },[session]);
  if(!session||!w) return null;
  return <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-4 space-y-2">
    <div className="flex justify-between"><b>DAH Coins</b><span className="text-xs text-neutral-400">Trading disabled</span></div>
    <div className="grid grid-cols-2 gap-2 text-sm">
      <div className="p-3 rounded-xl bg-neutral-900"><div className="text-xs text-neutral-400">Available</div><div className="text-lg font-bold">{w.available}</div></div>
      <div className="p-3 rounded-xl bg-neutral-900"><div className="text-xs text-neutral-400">Locked (College)</div><div className="text-lg font-bold">{w.lockedForCollege}</div></div>
    </div>
  </div>;
}
