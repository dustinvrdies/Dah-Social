import { sql } from "drizzle-orm";
import {
  pgTable,
  text,
  varchar,
  timestamp,
  boolean,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

/**
 * Core tables for DAH Social.
 *
 * Notes:
 * - We keep ids as UUID strings (gen_random_uuid()) to play nicely with Postgres + Drizzle.
 * - For MVP, we store password *hashes* (never plaintext) in users.passwordHash.
 */

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const posts = pgTable(
  "posts",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    userId: varchar("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    content: text("content").notNull(),
    isDeleted: boolean("is_deleted").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    userIdIdx: index("posts_user_id_idx").on(t.userId),
    createdAtIdx: index("posts_created_at_idx").on(t.createdAt),
  }),
);

export const comments = pgTable(
  "comments",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    postId: varchar("post_id")
      .notNull()
      .references(() => posts.id, { onDelete: "cascade" }),
    userId: varchar("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    content: text("content").notNull(),
    isDeleted: boolean("is_deleted").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    postIdIdx: index("comments_post_id_idx").on(t.postId),
    userIdIdx: index("comments_user_id_idx").on(t.userId),
    createdAtIdx: index("comments_created_at_idx").on(t.createdAt),
  }),
);

// Zod schemas (server input validation)
/**
 * Profiles (public user metadata)
 */
export const profiles = pgTable(
  "profiles",
  {
    userId: varchar("user_id")
      .primaryKey()
      .references(() => users.id, { onDelete: "cascade" }),
    displayName: text("display_name"),
    bio: text("bio"),
    avatarUrl: text("avatar_url"),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    userIdIdx: index("profiles_user_id_idx").on(t.userId),
  }),
);

/**
 * Post likes (many-to-many)
 */
export const postLikes = pgTable(
  "post_likes",
  {
    userId: varchar("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    postId: varchar("post_id")
      .notNull()
      .references(() => posts.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    likeUniq: uniqueIndex("post_likes_user_post_uniq").on(t.userId, t.postId),
    postIdIdx: index("post_likes_post_id_idx").on(t.postId),
    userIdIdx: index("post_likes_user_id_idx").on(t.userId),
  }),
);

/**
 * Follows (many-to-many)
 */
export const follows = pgTable(
  "follows",
  {
    followerId: varchar("follower_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    followingId: varchar("following_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    followUniq: uniqueIndex("follows_follower_following_uniq").on(t.followerId, t.followingId),
    followerIdx: index("follows_follower_id_idx").on(t.followerId),
    followingIdx: index("follows_following_id_idx").on(t.followingId),
  }),
);

/**
 * Abuse reports
 */
export const reports = pgTable(
  "reports",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    reporterId: varchar("reporter_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    targetType: text("target_type").notNull(), // "post" | "comment" | "user"
    targetId: varchar("target_id").notNull(),
    reason: text("reason").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    reporterIdx: index("reports_reporter_id_idx").on(t.reporterId),
    targetIdx: index("reports_target_idx").on(t.targetType, t.targetId),
    createdIdx: index("reports_created_at_idx").on(t.createdAt),
  }),
);


export const registerSchema = z.object({
  username: z
    .string()
    .trim()
    .min(3, "Username must be at least 3 characters")
    .max(32, "Username too long")
    .regex(/^[a-z0-9_]+$/i, "Username may contain letters, numbers, underscore"),
  password: z.string().min(8, "Password must be at least 8 characters").max(200),
});

export const loginSchema = z.object({
  username: z.string().trim().min(1),
  password: z.string().min(1),
});

export const createPostSchema = z.object({
  content: z.string().trim().min(1, "Post cannot be empty").max(5000, "Post too long"),
});

export const createCommentSchema = z.object({
  postId: z.string().min(1),
  content: z.string().trim().min(1, "Comment cannot be empty").max(2000, "Comment too long"),
});

// Insert schemas for DB insert convenience
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  passwordHash: true,
});

export const insertPostSchema = createInsertSchema(posts).pick({
  userId: true,
  content: true,
});

export const insertCommentSchema = createInsertSchema(comments).pick({
  postId: true,
  userId: true,
  content: true,
});

export const updateProfileSchema = z.object({
  displayName: z.string().trim().min(1).max(60).optional(),
  bio: z.string().trim().max(280).optional(),
  avatarUrl: z.string().url().max(500).optional(),
});

export const reportSchema = z.object({
  targetType: z.enum(["post", "comment", "user"]),
  targetId: z.string().min(1),
  reason: z.string().trim().min(3).max(500),
});

// Types
export type User = typeof users.$inferSelect;
export type Post = typeof posts.$inferSelect;
export type Comment = typeof comments.$inferSelect;
export type Profile = typeof profiles.$inferSelect;
export type PostLike = typeof postLikes.$inferSelect;
export type Follow = typeof follows.$inferSelect;
export type Report = typeof reports.$inferSelect;

export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type CreatePostInput = z.infer<typeof createPostSchema>;
export type CreateCommentInput = z.infer<typeof createCommentSchema>;
export type UpdateProfileInput = z.infer<typeof updateProfileSchema>;
export type ReportInput = z.infer<typeof reportSchema>;
