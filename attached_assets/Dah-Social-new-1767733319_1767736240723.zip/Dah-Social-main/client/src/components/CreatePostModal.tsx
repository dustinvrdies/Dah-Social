import { useState } from "react";
import { useAuth } from "./AuthProvider";
import { addCoins } from "@/lib/dahCoins";
import { pushNotification } from "@/lib/notifications";
import type { TextPost } from "@/lib/postTypes";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { createPost } from "@/lib/postsApi";

export function CreatePostModal({
  disabled,
  onCreated,
}: {
  disabled?: boolean;
  onCreated?: (p: TextPost) => void;
}) {
  const { session } = useAuth();
  const [open, setOpen] = useState(false);
  const [content, setContent] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const canSubmit = content.trim().length >= 1 && content.trim().length <= 2000;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button disabled={disabled} variant="secondary">
          Post
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create a post</DialogTitle>
        </DialogHeader>

        <div className="space-y-3">
          <Textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="What are you building today?" />

          {err && <div className="text-sm text-red-400">{err}</div>}

          <Button
            disabled={!session || !canSubmit}
            onClick={async () => {
              if (!session) return;
              setErr(null);
              try {
                const res = await createPost(content.trim());
                const p: TextPost = {
                  id: res.post.id,
                  type: "text",
                  user: res.post.username,
                  content: res.post.content,
                  createdAt: res.post.createdAt,
                  likeCount: res.post.likeCount ?? 0,
                  commentCount: res.post.commentCount ?? 0,
                  viewerLiked: res.post.viewer?.liked ?? false,
                  displayName: res.post.profile?.displayName ?? null,
                  avatarUrl: res.post.profile?.avatarUrl ?? null,
                };
                addCoins(session.user.username, "Created a post", 2);
                pushNotification({
                  title: "Post created",
                  message: "Your post is now live in the feed.",
                });
                onCreated?.(p);
                setContent("");
                setOpen(false);
              } catch (e: any) {
                setErr(e?.message || "Could not create post");
              }
            }}
          >
            Publish
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
