import { createContext, useContext, useEffect, useMemo, useState, ReactNode } from "react";
import type { Session } from "@/lib/auth";
import { getSession, login as apiLogin, logout as apiLogout, register as apiRegister } from "@/lib/auth";

type AuthCtx = {
  session: Session | null;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<void>;
  register: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthCtx>({
  session: null,
  isLoading: true,
  login: async () => {},
  register: async () => {},
  logout: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const s = await getSession();
        if (mounted) setSession(s);
      } finally {
        if (mounted) setIsLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  const value = useMemo<AuthCtx>(
    () => ({
      session,
      isLoading,
      login: async (username: string, password: string) => {
        const s = await apiLogin(username, password);
        setSession(s);
      },
      register: async (username: string, password: string) => {
        const s = await apiRegister(username, password);
        setSession(s);
      },
      logout: async () => {
        await apiLogout();
        setSession(null);
      },
    }),
    [session, isLoading],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
