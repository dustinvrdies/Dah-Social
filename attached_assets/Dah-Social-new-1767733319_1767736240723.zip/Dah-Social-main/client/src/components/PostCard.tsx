import { useMemo, useState } from "react";
import { Link } from "wouter";
import { useAuth } from "./AuthProvider";
import { addCoins } from "@/lib/dahCoins";
import { pushNotification } from "@/lib/notifications";
import { hidePost } from "@/lib/moderation";
import type { TextPost } from "@/lib/postTypes";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Heart, Flag, EyeOff } from "lucide-react";
import { likePost, unlikePost } from "@/lib/postsApi";
import { fetchJson } from "@/lib/api";

export function PostCard({ post }: { post: TextPost }) {
  const { session } = useAuth();
  const [liked, setLiked] = useState(!!post.viewerLiked);
  const [likeCount, setLikeCount] = useState(post.likeCount ?? 0);
  const username = post.user;
  const title = useMemo(() => post.displayName || username, [post.displayName, username]);

  const canInteract = !!session;

  return (
    <Card className="p-4 space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <Link href={`/profile?u=${encodeURIComponent(username)}`} className="font-semibold truncate">
              {title}
            </Link>
            <span className="text-xs text-muted-foreground truncate">@{username}</span>
          </div>
          {post.createdAt && <div className="text-xs text-muted-foreground">{new Date(post.createdAt).toLocaleString()}</div>}
        </div>

        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => {
              const who = session?.user.username ?? "guest";
              hidePost(who, post.id);
              pushNotification({ title: "Hidden", message: "This post is now hidden from your feed." });
            }}
            title="Hide post"
          >
            <EyeOff className="h-4 w-4" />
          </Button>

          <Button
            size="sm"
            variant="ghost"
            disabled={!canInteract}
            onClick={async () => {
              try {
                await fetchJson("/api/reports", {
                  method: "POST",
                  body: JSON.stringify({ targetType: "post", targetId: post.id, reason: "Inappropriate content" }),
                });
                pushNotification({ title: "Reported", message: "Thanks. Your report was submitted." });
              } catch (e: any) {
                pushNotification({ title: "Report failed", message: e?.message || "Could not submit report." });
              }
            }}
            title={canInteract ? "Report post" : "Log in to report"}
          >
            <Flag className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="whitespace-pre-wrap break-words">{post.content}</div>

      <div className="flex items-center gap-2">
        <Button
          variant={liked ? "default" : "secondary"}
          size="sm"
          disabled={!canInteract}
          onClick={async () => {
            if (!session) return;
            try {
              if (liked) {
                await unlikePost(post.id);
                setLiked(false);
                setLikeCount((c) => Math.max(0, c - 1));
              } else {
                await likePost(post.id);
                setLiked(true);
                setLikeCount((c) => c + 1);
                addCoins(session.user.username, "Liked a post", 1);
              }
            } catch (e: any) {
              pushNotification({ title: "Action failed", message: e?.message || "Please try again." });
            }
          }}
        >
          <Heart className="h-4 w-4 mr-2" />
          {likeCount}
        </Button>

        <div className="text-xs text-muted-foreground">
          {post.commentCount ?? 0} comments
        </div>
      </div>
    </Card>
  );
}
