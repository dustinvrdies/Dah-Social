import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import { MainNav } from "@/components/MainNav";
import { useAuth } from "@/components/AuthProvider";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const { login, register, isLoading, session } = useAuth();

  const [mode, setMode] = useState<"login" | "register">("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const canSubmit = useMemo(() => username.trim().length >= 3 && password.length >= 6, [username, password]);

  if (!isLoading && session) {
    // already logged in
    setTimeout(() => setLocation("/"), 0);
  }

  return (
    <main className="min-h-screen bg-background text-foreground">
      <MainNav />
      <div className="max-w-md mx-auto p-4">
        <Card className="p-4">
          <div className="space-y-2">
            <h1 className="text-xl font-semibold">{mode === "login" ? "Log in" : "Create account"}</h1>
            <p className="text-sm text-muted-foreground">
              {mode === "login"
                ? "Log in to post, like, follow, and customize your profile."
                : "Create your DAH Social account to start posting."}
            </p>

            <div className="space-y-3 pt-2">
              <div className="space-y-1">
                <label className="text-sm">Username</label>
                <Input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="dustin" autoCapitalize="none" />
              </div>
              <div className="space-y-1">
                <label className="text-sm">Password</label>
                <Input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="minimum 6 chars" type="password" />
              </div>

              {err && <div className="text-sm text-red-400">{err}</div>}

              <Button
                className="w-full"
                disabled={!canSubmit}
                onClick={async () => {
                  setErr(null);
                  try {
                    if (mode === "login") await login(username.trim(), password);
                    else await register(username.trim(), password);
                    setLocation("/");
                  } catch (e: any) {
                    setErr(e?.message || "Something went wrong");
                  }
                }}
              >
                {mode === "login" ? "Log in" : "Create account"}
              </Button>

              <Button
                className="w-full"
                variant="secondary"
                onClick={() => setMode((m) => (m === "login" ? "register" : "login"))}
              >
                {mode === "login" ? "Need an account? Create one" : "Have an account? Log in"}
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </main>
  );
}
