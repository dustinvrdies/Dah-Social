import { fetchJson } from "./api";

export type ApiPost = {
  id: string;
  userId: string;
  content: string;
  createdAt: string;
  username: string;
  profile: { displayName?: string | null; avatarUrl?: string | null } | null;
  likeCount: number;
  commentCount: number;
  viewer?: { liked: boolean };
};

export async function listPosts(limit = 30, cursor?: string) {
  const q = new URLSearchParams();
  q.set("limit", String(limit));
  if (cursor) q.set("cursor", cursor);
  return fetchJson<{ posts: ApiPost[]; nextCursor: string | null }>(`/api/posts?${q.toString()}`, { method: "GET" });
}

export async function createPost(content: string) {
  return fetchJson<{ post: ApiPost }>("/api/posts", {
    method: "POST",
    body: JSON.stringify({ content }),
  });
}

export async function likePost(postId: string) {
  return fetchJson<{ ok: true }>(`/api/posts/${postId}/like`, { method: "POST" });
}

export async function unlikePost(postId: string) {
  return fetchJson<{ ok: true }>(`/api/posts/${postId}/unlike`, { method: "POST" });
}
