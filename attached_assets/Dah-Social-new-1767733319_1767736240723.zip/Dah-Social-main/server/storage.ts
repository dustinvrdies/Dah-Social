import { db } from "./db";
import {
  users,
  profiles,
  posts,
  comments,
  postLikes,
  follows,
  reports,
  type User,
  type Profile,
  type Post,
  type Comment,
} from "@shared/schema";
import { and, desc, eq, sql } from "drizzle-orm";

export interface PublicUser {
  id: string;
  username: string;
  profile: Profile | null;
  counts: {
    followers: number;
    following: number;
    posts: number;
  };
  viewer?: {
    isFollowing: boolean;
  };
}

export interface PostWithMeta extends Post {
  username: string;
  profile: Profile | null;
  likeCount: number;
  commentCount: number;
  viewer?: { liked: boolean };
}

export interface CommentWithMeta extends Comment {
  username: string;
  profile: Profile | null;
}

export interface IStorage {
  // Users
  getUserById(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(username: string, passwordHash: string): Promise<User>;

  // Profile
  getProfileByUserId(userId: string): Promise<Profile | undefined>;
  upsertProfile(userId: string, data: { displayName?: string; bio?: string; avatarUrl?: string }): Promise<Profile>;

  // Public user
  getPublicUserByUsername(username: string, viewerId?: string): Promise<PublicUser | undefined>;

  // Posts
  listPosts(limit: number, cursor?: string, viewerId?: string): Promise<{ posts: PostWithMeta[]; nextCursor: string | null }>;
  createPost(userId: string, content: string): Promise<Post>;
  softDeletePost(postId: string, userId: string): Promise<boolean>;

  // Likes
  likePost(postId: string, userId: string): Promise<void>;
  unlikePost(postId: string, userId: string): Promise<void>;

  // Comments
  listComments(postId: string, limit: number, cursor?: string): Promise<{ comments: CommentWithMeta[]; nextCursor: string | null }>;
  createComment(postId: string, userId: string, content: string): Promise<Comment>;
  softDeleteComment(commentId: string, userId: string): Promise<boolean>;

  // Follows
  followUser(targetUserId: string, followerId: string): Promise<void>;
  unfollowUser(targetUserId: string, followerId: string): Promise<void>;

  // Reports
  createReport(reporterId: string, targetType: "post" | "comment" | "user", targetId: string, reason: string): Promise<void>;
}

export class DbStorage implements IStorage {
  async getUserById(id: string) {
    const [u] = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return u;
  }

  async getUserByUsername(username: string) {
    const [u] = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return u;
  }

  async createUser(username: string, passwordHash: string) {
    const [u] = await db
      .insert(users)
      .values({ username, passwordHash })
      .returning();
    return u;
  }

  async getProfileByUserId(userId: string) {
    const [p] = await db.select().from(profiles).where(eq(profiles.userId, userId)).limit(1);
    return p;
  }

  async upsertProfile(userId: string, data: { displayName?: string; bio?: string; avatarUrl?: string }) {
    // Upsert using ON CONFLICT (user_id) DO UPDATE.
    const [p] = await db
      .insert(profiles)
      .values({
        userId,
        displayName: data.displayName,
        bio: data.bio,
        avatarUrl: data.avatarUrl,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: profiles.userId,
        set: {
          displayName: data.displayName,
          bio: data.bio,
          avatarUrl: data.avatarUrl,
          updatedAt: new Date(),
        },
      })
      .returning();
    return p;
  }

  async getPublicUserByUsername(username: string, viewerId?: string) {
    const u = await this.getUserByUsername(username);
    if (!u) return undefined;

    const [p] = await db.select().from(profiles).where(eq(profiles.userId, u.id)).limit(1);

    const [{ c: followerCount }] = await db
      .select({ c: sql<number>`count(*)` })
      .from(follows)
      .where(eq(follows.followingId, u.id));

    const [{ c: followingCount }] = await db
      .select({ c: sql<number>`count(*)` })
      .from(follows)
      .where(eq(follows.followerId, u.id));

    const [{ c: postCount }] = await db
      .select({ c: sql<number>`count(*)` })
      .from(posts)
      .where(and(eq(posts.userId, u.id), eq(posts.isDeleted, false)));

    let isFollowing = false;
    if (viewerId) {
      const [row] = await db
        .select({ one: sql<number>`1` })
        .from(follows)
        .where(and(eq(follows.followerId, viewerId), eq(follows.followingId, u.id)))
        .limit(1);
      isFollowing = !!row;
    }

    return {
      id: u.id,
      username: u.username,
      profile: p ?? null,
      counts: {
        followers: Number(followerCount ?? 0),
        following: Number(followingCount ?? 0),
        posts: Number(postCount ?? 0),
      },
      viewer: viewerId ? { isFollowing } : undefined,
    };
  }

  async listPosts(limit: number, cursor?: string, viewerId?: string) {
    // Cursor is post id; we paginate by createdAt desc, then id desc (stable).
    // For MVP we use createdAt+id in the query, but accept id-only cursor.
    // We'll look up cursor createdAt when cursor provided.
    let cursorCreatedAt: Date | null = null;
    if (cursor) {
      const [c] = await db.select({ createdAt: posts.createdAt }).from(posts).where(eq(posts.id, cursor)).limit(1);
      cursorCreatedAt = c?.createdAt ?? null;
    }

    const where = cursorCreatedAt
      ? and(
          eq(posts.isDeleted, false),
          sql`(${posts.createdAt}, ${posts.id}) < (${cursorCreatedAt}, ${cursor})`,
        )
      : eq(posts.isDeleted, false);

    const rows = await db
      .select({
        post: posts,
        username: users.username,
        profile: profiles,
        likeCount: sql<number>`coalesce(lc.cnt, 0)`,
        commentCount: sql<number>`coalesce(cc.cnt, 0)`,
        viewerLiked: viewerId ? sql<number>`case when vl.user_id is null then 0 else 1 end` : sql<number>`0`,
      })
      .from(posts)
      .innerJoin(users, eq(users.id, posts.userId))
      .leftJoin(profiles, eq(profiles.userId, users.id))
      .leftJoin(
        sql`(
          select post_id, count(*)::int as cnt
          from post_likes
          group by post_id
        ) as lc`,
        sql`lc.post_id = ${posts.id}`,
      )
      .leftJoin(
        sql`(
          select post_id, count(*)::int as cnt
          from comments
          where is_deleted = false
          group by post_id
        ) as cc`,
        sql`cc.post_id = ${posts.id}`,
      )
      .leftJoin(
        viewerId
          ? sql`(
              select post_id, user_id
              from post_likes
              where user_id = ${viewerId}
            ) as vl`
          : sql`(select null::varchar as post_id, null::varchar as user_id) as vl`,
        sql`vl.post_id = ${posts.id}`,
      )
      .where(where)
      .orderBy(desc(posts.createdAt), desc(posts.id))
      .limit(limit);

    const mapped: PostWithMeta[] = rows.map((r: any) => ({
      ...r.post,
      username: r.username,
      profile: r.profile ?? null,
      likeCount: Number(r.likeCount ?? 0),
      commentCount: Number(r.commentCount ?? 0),
      viewer: viewerId ? { liked: Number(r.viewerLiked) === 1 } : undefined,
    }));

    const nextCursor = mapped.length === limit ? mapped[mapped.length - 1].id : null;
    return { posts: mapped, nextCursor };
  }

  async createPost(userId: string, content: string) {
    const [p] = await db.insert(posts).values({ userId, content }).returning();
    return p;
  }

  async softDeletePost(postId: string, userId: string) {
    const res = await db
      .update(posts)
      .set({ isDeleted: true, deletedAt: new Date() })
      .where(and(eq(posts.id, postId), eq(posts.userId, userId), eq(posts.isDeleted, false)))
      .returning({ id: posts.id });
    return res.length > 0;
  }

  async likePost(postId: string, userId: string) {
    // Ignore duplicates via unique constraint; swallow conflict.
    await db
      .insert(postLikes)
      .values({ postId, userId })
      .onConflictDoNothing();
  }

  async unlikePost(postId: string, userId: string) {
    await db.delete(postLikes).where(and(eq(postLikes.postId, postId), eq(postLikes.userId, userId)));
  }

  async listComments(postId: string, limit: number, cursor?: string) {
    let cursorCreatedAt: Date | null = null;
    if (cursor) {
      const [c] = await db.select({ createdAt: comments.createdAt }).from(comments).where(eq(comments.id, cursor)).limit(1);
      cursorCreatedAt = c?.createdAt ?? null;
    }

    const where = cursorCreatedAt
      ? and(
          eq(comments.isDeleted, false),
          eq(comments.postId, postId),
          sql`(${comments.createdAt}, ${comments.id}) < (${cursorCreatedAt}, ${cursor})`,
        )
      : and(eq(comments.isDeleted, false), eq(comments.postId, postId));

    const rows = await db
      .select({
        comment: comments,
        username: users.username,
        profile: profiles,
      })
      .from(comments)
      .innerJoin(users, eq(users.id, comments.userId))
      .leftJoin(profiles, eq(profiles.userId, users.id))
      .where(where)
      .orderBy(desc(comments.createdAt), desc(comments.id))
      .limit(limit);

    const mapped: CommentWithMeta[] = rows.map((r: any) => ({
      ...r.comment,
      username: r.username,
      profile: r.profile ?? null,
    }));

    const nextCursor = mapped.length === limit ? mapped[mapped.length - 1].id : null;
    return { comments: mapped, nextCursor };
  }

  async createComment(postId: string, userId: string, content: string) {
    const [c] = await db.insert(comments).values({ postId, userId, content }).returning();
    return c;
  }

  async softDeleteComment(commentId: string, userId: string) {
    const res = await db
      .update(comments)
      .set({ isDeleted: true, deletedAt: new Date() })
      .where(and(eq(comments.id, commentId), eq(comments.userId, userId), eq(comments.isDeleted, false)))
      .returning({ id: comments.id });
    return res.length > 0;
  }

  async followUser(targetUserId: string, followerId: string) {
    if (targetUserId === followerId) return;
    await db.insert(follows).values({ followerId, followingId: targetUserId }).onConflictDoNothing();
  }

  async unfollowUser(targetUserId: string, followerId: string) {
    await db.delete(follows).where(and(eq(follows.followerId, followerId), eq(follows.followingId, targetUserId)));
  }

  async createReport(reporterId: string, targetType: "post" | "comment" | "user", targetId: string, reason: string) {
    await db.insert(reports).values({ reporterId, targetType, targetId, reason });
  }
}

export const storage = new DbStorage();
